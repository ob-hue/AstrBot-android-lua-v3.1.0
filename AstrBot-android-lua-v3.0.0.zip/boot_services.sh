#!/bin/sh
# =============================================================================
# boot_services.sh —— v2.3.0 启动与"防重置" + Ollama 全栈整合
#
# P7：App 自带的启动器每次启动都固定重写 webui.json，把 autoLoginAccount
#     和 token 清空 → 每次都得重新扫码。改配置没用，只能在它写完后抢回来。
# P3：点 ▶ 会触发上面那条启动器，所以别点 ▶，走 start_napcat.sh 或本脚本。
#
# 对策（两条路，自动选）：
#   路线 A（首选）：start_napcat.sh —— 它不改写配置
#   路线 B（兜底）：只能走 App 启动器时，启动后每 100ms 盯一次，一发现被写成
#                   空白就立刻用备份原子覆盖回去，盯 WATCH_SECS 秒（默认 60）
#
# v2.3.0 新增 Ollama：
#   start 分支的第一件事（在 AstrBot 之前）是拉起 ollama serve，
#   并用 /dev/tcp 轮询 11434 直到端口就绪；就绪后预热本地向量模型
#   （默认 nomic-embed-text）。没装 Ollama 不算失败，只标记 absent。
#
# 用法：
#   sh boot_services.sh            启动全部（Ollama → NapCat → AstrBot + 清理守护）
#   sh boot_services.sh status     状态 JSON（napcat / astrbot / ollama）
#   sh boot_services.sh stop       全停
#   sh boot_services.sh ollama     只拉起 Ollama 并预热向量模型
#   sh boot_services.sh snapshot   把手上的好配置存成备份
#   sh boot_services.sh restore    手工把备份盖回空白 webui.json（验证防重置用）
#   sh boot_services.sh watch      只跑后台盯守 WATCH_SECS 秒（验证用，不起 NapCat）
#   sh boot_services.sh clean      后台起定时清理守护（幂等，带 pid 锁）
#   sh boot_services.sh clean-stop 停掉清理守护
# =============================================================================
set -u

APP_HOME="${APP_HOME:-/root}"
QQ_UIN="${QQ_UIN:-}"                        # 多实例时用它精确指定恢复哪个实例
NAPCAT_PORT="${NAPCAT_PORT:-6100}"
ASTRBOT_PORT="${ASTRBOT_PORT:-6185}"
OLLAMA_PORT="${OLLAMA_PORT:-11434}"         # v2.3.0：Ollama 固定 11434
OLLAMA_MODEL="${OLLAMA_MODEL:-nomic-embed-text}"   # 本地向量模型
OLLAMA_WAIT="${OLLAMA_WAIT:-30}"            # 等 Ollama 就绪的秒数
OLLAMA_AUTO_PULL="${OLLAMA_AUTO_PULL:-0}"   # 1=模型缺失时自动 ollama pull（需联网）
WEBUI_KEEP="$APP_HOME/.webui.json.keep"     # 备份：正确的 webui.json
RESTORE_MODE="${RESTORE_MODE:-full}"        # full=整份覆盖 | account=只回填账号、保留新 token
WATCH_SECS="${WATCH_SECS:-60}"              # 启动后盯 WebUI 配置的秒数
CLEAN_PID="$APP_HOME/.clean_daemon.pid"
# 数字型环境变量兜底：写错不该让启动脚本在数值比较处崩掉
case "$OLLAMA_PORT" in ''|*[!0-9]*) OLLAMA_PORT=11434 ;; esac
case "$OLLAMA_WAIT" in ''|*[!0-9]*) OLLAMA_WAIT=30 ;; esac

log() { echo "[$(date '+%H:%M:%S')] $*"; }
# 端口探测：/bin/sh 在 Debian 下可能是 dash（不支持 /dev/tcp），
# 所以失败后再借 bash 试一次；两者都不行才判 down。
port_open() {
  ( echo >/dev/tcp/127.0.0.1/"$1" ) >/dev/null 2>&1 && return 0
  command -v bash >/dev/null 2>&1 || return 1
  bash -c "echo >/dev/tcp/127.0.0.1/$1" >/dev/null 2>&1
}
alive() { [ -n "$1" ] && ps -p "$1" >/dev/null 2>&1; }

find_webui_json() { ls -t "$APP_HOME"/napcat_instances/*/config/webui.json 2>/dev/null | head -1; }
all_webui_json()  { ls -t "$APP_HOME"/napcat_instances/*/config/webui.json 2>/dev/null; }
find_launcher()   { ls -t "$APP_HOME"/launcher_qq*.sh 2>/dev/null | head -1; }

has_account() {  # 某个 webui.json 里有没有非空的 autoLoginAccount
  grep -q '"autoLoginAccount"[[:space:]]*:[[:space:]]*"[^"]\+"' "$1" 2>/dev/null
}
keep_ok() { [ -f "$WEBUI_KEEP" ] && has_account "$WEBUI_KEEP"; }

# ---------- 挑目标：必须是"空白"的那一个，不能只按 mtime 取最新 ----------
# 老写法 ls -t | head -1 在多实例时会挑中"已经正常"的实例，导致真正被重置的
# 那个永远轮不到恢复（实测复现）。
target_webui() {
  _l="$APP_HOME/.webui.list.$$"
  all_webui_json > "$_l" 2>/dev/null
  _total=$(wc -l < "$_l" | tr -d ' ')
  [ "${_total:-0}" -ge 1 ] || { rm -f "$_l"; return 1; }
  _hit=""; _hits=0
  while read -r wj; do
    [ -n "$wj" ] || continue
    if [ -n "$QQ_UIN" ]; then
      case "$wj" in *"$QQ_UIN"*) ;; *) continue ;; esac
    fi
    has_account "$wj" && continue        # 已经有账号，不碰
    [ "$_hits" -eq 0 ] && _hit="$wj"
    _hits=$((_hits + 1))
  done < "$_l"
  rm -f "$_l"
  [ "$_hits" -ge 1 ] || return 1
  if [ "$_hits" -gt 1 ]; then
    log "⚠️ 有 $_hits 个空白 webui.json，只恢复最新的一个: $_hit" >&2
  elif [ "$_total" -gt 1 ] && [ -z "$QQ_UIN" ]; then
    log "ℹ️ 共 $_total 个实例，本次只恢复 $_hit（多实例建议设 QQ_UIN）" >&2
  fi
  echo "$_hit"
}

# ---------- 原子写入：先写临时文件再 mv，避免 NapCat 读到半截 JSON ----------
apply_keep() {
  _tgt="$1"
  keep_ok || return 1                 # 备份本身是空白就绝不写（防止越修越坏）
  _tmp="$_tgt.tmp.$$"
  if [ "$RESTORE_MODE" = "account" ]; then
    # 只回填 autoLoginAccount，保留 NapCat 刚生成的新 token（P8：token 会轮换）
    _acc=$(sed -n 's/.*"autoLoginAccount"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$WEBUI_KEEP" | head -1)
    [ -n "$_acc" ] || return 1
    sed "s#\(\"autoLoginAccount\"[[:space:]]*:[[:space:]]*\)\"[^\"]*\"#\1\"$_acc\"#" "$_tgt" > "$_tmp" 2>/dev/null || return 1
  else
    cp -f "$WEBUI_KEEP" "$_tmp" 2>/dev/null || return 1
  fi
  [ -s "$_tmp" ] || { rm -f "$_tmp"; return 1; }
  mv -f "$_tmp" "$_tgt" 2>/dev/null || { rm -f "$_tmp"; return 1; }
  has_account "$_tgt"                 # 写完必须能读回账号才算成功
}

# ---------- 覆盖：只在对方被清空时动手 ----------
restore_config() {
  keep_ok || return 1
  _wj=$(target_webui) || return 1
  [ -n "$_wj" ] || return 1
  apply_keep "$_wj" && { log "已用备份覆盖空白 webui.json: $_wj"; return 0; }
  return 1
}

# ---------- 备份：把当前"好配置"存下来 ----------
snapshot_config() {
  _wj=$(find_webui_json)
  [ -n "$_wj" ] || { log "没有 webui.json，无法备份"; return 1; }
  if has_account "$_wj"; then
    cp -f "$_wj" "$WEBUI_KEEP" && log "已备份正确配置 → $WEBUI_KEEP"
    return 0
  fi
  if [ -f "$WEBUI_KEEP" ]; then
    log "当前 webui.json 是空白，备份仍保留（不覆盖）"
    return 0
  fi
  log "当前没有可备份的登录账号（autoLoginAccount 为空）"
  return 1
}

# ---------- 后台盯 WATCH_SECS 秒：抢在 NapCat 读配置前把备份写回去 ----------
# 输出重定向到独立日志：绝不能占着父进程 stdout，否则 host.spawn 的
# "全栈启动"任务会一直不结束。
watch_and_restore() {
  _ws="$WATCH_SECS"; case "$_ws" in ''|*[!0-9]*) _ws=60 ;; esac
  ( i=0; n=$((_ws * 10))
    while [ "$i" -lt "$n" ]; do
      restore_config >/dev/null 2>&1
      i=$((i + 1))
      sleep 0.1 2>/dev/null || sleep 1
    done
    log "（后台）盯守结束 ${_ws}s" >>"$APP_HOME/.webui_watch.log" 2>&1
  ) >>"$APP_HOME/.webui_watch.log" 2>&1 &
}

# =============================================================================
# v2.3.0 · Ollama 本地向量模型
# =============================================================================
# 二进制可能在 PATH，也可能被 App 放在 /root/.ollama/ollama；两处都找。
find_ollama() {
  for _c in "$APP_HOME/.ollama/ollama" /root/.ollama/ollama \
            /usr/local/bin/ollama /usr/bin/ollama /bin/ollama; do
    [ -x "$_c" ] && { echo "$_c"; return 0; }
  done
  command -v ollama 2>/dev/null
}

# 向量模型预热：模型不在就只提示（默认不联网拉取，避免开机卡在下载）
ollama_warm() {
  _m="$OLLAMA_MODEL"
  [ -n "$_m" ] || return 0
  _bin=$(find_ollama)
  [ -n "$_bin" ] || return 0
  if "$_bin" list 2>/dev/null | awk 'NR>1{print $1}' | grep -qx -e "$_m" -e "$_m:latest"; then
    if command -v curl >/dev/null 2>&1; then
      if curl -s -m 20 "http://127.0.0.1:$OLLAMA_PORT/api/embed" \
           -d "{\"model\":\"$_m\",\"input\":\"ping\"}" 2>/dev/null | grep -q '"embedding' \
         || curl -s -m 20 "http://127.0.0.1:$OLLAMA_PORT/api/embeddings" \
           -d "{\"model\":\"$_m\",\"prompt\":\"ping\"}" 2>/dev/null | grep -q '"embedding'; then
        log "向量模型已预热: $_m"
      else
        log "⚠️ 向量模型预热超时: $_m（服务已就绪，首次调用会慢）"
      fi
    else
      log "向量模型在位: $_m（无 curl，跳过预热）"
    fi
    return 0
  fi
  if [ "$OLLAMA_AUTO_PULL" = "1" ]; then
    log "拉取向量模型: $_m（OLLAMA_AUTO_PULL=1）"
    if "$_bin" pull "$_m" >>"$APP_HOME/ollama.log" 2>&1; then
      log "向量模型已就绪: $_m"
    else
      log "⚠️ 拉取失败: $_m，看 $APP_HOME/ollama.log"
    fi
  else
    log "ℹ️ 未发现向量模型 $_m，跳过预热（设 OLLAMA_AUTO_PULL=1 可自动拉取）"
  fi
}

# 启动 Ollama：已在跑就只预热；没装则标 absent（不是错误）；起不来标 down。
start_ollama() {
  if port_open "$OLLAMA_PORT"; then log "Ollama 已在跑（:$OLLAMA_PORT）"; OLLAMA=up; ollama_warm; return; fi

  _bin=$(find_ollama)
  if [ -z "$_bin" ]; then
    log "ℹ️ 未安装 Ollama，跳过（AstrBot 的知识库/向量检索将不可用）"
    OLLAMA=absent; return
  fi

  log "启动 Ollama：$_bin serve（:$OLLAMA_PORT，模型 $OLLAMA_MODEL）"
  ( cd "$APP_HOME" && OLLAMA_HOST="0.0.0.0:$OLLAMA_PORT" \
      nohup "$_bin" serve >>"$APP_HOME/ollama.log" 2>&1 & )

  i=0
  while [ "$i" -lt "$OLLAMA_WAIT" ]; do
    sleep 1; i=$((i + 1))
    if port_open "$OLLAMA_PORT"; then
      log "Ollama 就绪（${i}s）"; OLLAMA=up
      ollama_warm
      return
    fi
  done
  OLLAMA=down; log "⚠️ Ollama ${OLLAMA_WAIT} 秒没起来，看 $APP_HOME/ollama.log"
}

# ---------- 启动 NapCat ----------
start_napcat() {
  if port_open "$NAPCAT_PORT"; then log "NapCat 已在跑"; NAPCAT=up; return; fi

  restore_config >/dev/null 2>&1        # 启动前先写一次（文件不存在时是 no-op）

  if [ -x "$APP_HOME/start_napcat.sh" ]; then
    log "启动 NapCat：start_napcat.sh（路线 A，不改写配置）"
    ( cd "$APP_HOME" && nohup /bin/sh "$APP_HOME/start_napcat.sh" >"$APP_HOME/napcat.log" 2>&1 & )
  else
    L=$(find_launcher)
    if [ -n "$L" ]; then
      log "启动 NapCat：$L（路线 B，需抢改配置）"
      ( cd "$APP_HOME" && nohup /bin/sh "$L" >"$APP_HOME/napcat.log" 2>&1 & )
    else
      log "⚠️ 找不到任何 NapCat 启动器"; NAPCAT=down; return
    fi
  fi

  watch_and_restore                    # 两条路都盯：NapCat 自己也可能重生成

  i=0
  while [ "$i" -lt 25 ]; do
    sleep 1; i=$((i + 1))
    if port_open "$NAPCAT_PORT"; then
      log "NapCat 就绪（${i}s）"; NAPCAT=up
      restore_config >/dev/null 2>&1   # 起来后再兜一次
      return
    fi
  done
  NAPCAT=down; log "⚠️ NapCat 25 秒没起来，看 $APP_HOME/napcat.log"
}

# ---------- 启动 AstrBot（必须用 .venv） ----------
start_astrbot() {
  if port_open "$ASTRBOT_PORT"; then log "AstrBot 已在跑"; ASTRBOT=up; return; fi
  D=""
  for c in "$APP_HOME/AstrBot" "$APP_HOME/astrbot"; do
    [ -f "$c/main.py" ] && { D="$c"; break; }
  done
  [ -n "$D" ] || D=$(find "$APP_HOME" -maxdepth 3 -name main.py -path "*AstrBot*" 2>/dev/null | head -1 | xargs -r dirname)
  if [ -z "$D" ] || [ ! -f "$D/main.py" ]; then log "⚠️ 没找到 AstrBot"; ASTRBOT=down; return; fi

  PY="$D/.venv/bin/python"
  [ -x "$PY" ] || PY="$(command -v python3)"
  log "启动 AstrBot：$D（$(basename "$PY")）"
  ( cd "$D" && nohup "$PY" main.py >>"$APP_HOME/astrbot.log" 2>&1 & )

  i=0
  while [ "$i" -lt 60 ]; do
    sleep 1; i=$((i + 1))
    if port_open "$ASTRBOT_PORT"; then log "AstrBot 就绪（${i}s）"; ASTRBOT=up; return; fi
  done
  ASTRBOT=down; log "⚠️ AstrBot 60 秒没起来，看 $APP_HOME/astrbot.log"
}

# ---------- 定时清理守护（clean_daemon.sh --loop） ----------
# 注意：clean_daemon.sh 本身没有 pid 文件，这里补上，防止越点越多份在跑。
clean_start() {
  [ -f "$APP_HOME/clean_daemon.sh" ] || { log "⚠️ 找不到 $APP_HOME/clean_daemon.sh"; return 1; }
  if [ -f "$CLEAN_PID" ] && alive "$(cat "$CLEAN_PID" 2>/dev/null)"; then
    log "清理守护已在跑（pid $(cat "$CLEAN_PID")）"; return 0
  fi
  nohup /bin/sh "$APP_HOME/clean_daemon.sh" --loop >>"$APP_HOME/.clean_daemon.boot.log" 2>&1 &
  echo $! > "$CLEAN_PID"
  sleep 1
  if alive "$(cat "$CLEAN_PID" 2>/dev/null)"; then
    log "清理守护已启动（pid $(cat "$CLEAN_PID")，每 ${CLEAN_INTERVAL:-7200}s 一轮）"
  else
    log "⚠️ 清理守护启动失败，看 $APP_HOME/.clean_daemon.boot.log"; rm -f "$CLEAN_PID"
    return 1
  fi
}

clean_stop() {
  if [ -f "$CLEAN_PID" ] && alive "$(cat "$CLEAN_PID" 2>/dev/null)"; then
    p=$(cat "$CLEAN_PID")
    kill "$p" 2>/dev/null
    log "已请求停止清理守护（pid $p）"
  else
    log "清理守护没在跑"
  fi
  rm -f "$CLEAN_PID"
}

status_json() {
  n=down; a=down; o=down
  port_open "$NAPCAT_PORT" && n=up
  port_open "$ASTRBOT_PORT" && a=up
  [ -n "$(find_ollama)" ] || o=absent
  port_open "$OLLAMA_PORT" && o=up
  printf '{"napcat":"%s","astrbot":"%s","ollama":"%s","at":"%s"}\n' \
    "$n" "$a" "$o" "$(date '+%Y-%m-%d %H:%M:%S')"
}

case "${1:-start}" in
  status)   status_json ;;
  snapshot) snapshot_config ;;
  restore)
    if restore_config; then log "恢复成功"; else log "无需恢复（已登录 / 无备份 / 无 webui.json）"; fi ;;
  watch)
    watch_and_restore
    log "后台盯守 ${WATCH_SECS}s，日志: $APP_HOME/.webui_watch.log" ;;
  ollama)
    OLLAMA=down
    start_ollama
    log "Ollama=$OLLAMA" ;;
  clean)      clean_start ;;
  clean-stop) clean_stop ;;
  stop)
    log "停止"
    pkill -f "napcat" 2>/dev/null
    pkill -f "AstrBot.*main.py" 2>/dev/null
    pkill -f "ollama serve" 2>/dev/null
    sleep 2; status_json ;;
  start|"")
    log "=== 全栈启动 ==="
    NAPCAT=down; ASTRBOT=down; OLLAMA=down
    snapshot_config        # 万一备份丢了，先补上
    clean_start            # v2.2.1：一键启动顺带拉起定时清理守护（幂等，带 pid 锁）
    start_ollama           # v2.3.0：AstrBot 之前先起本地向量模型，并等 11434 就绪
    start_napcat
    start_astrbot
    status_json
    log "=== 完成：Ollama=$OLLAMA NapCat=$NAPCAT AstrBot=$ASTRBOT ===" ;;
  *) echo "用法: $0 [start|status|stop|ollama|snapshot|restore|watch|clean|clean-stop]" >&2; exit 2 ;;
esac
