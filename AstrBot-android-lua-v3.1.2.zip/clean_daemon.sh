#!/bin/sh
# =============================================================================
# clean_daemon.sh —— AstrBot-android-lua 磁盘守卫（v3.1.2 · 生产级重写）
#
# 设计目标：在一个"会删文件"的脚本里，把"误删"的概率压到最低。
#
# 三重保险
#   ① 模式分级
#        不带参数            → report：只读体检，绝不删除/修改任何文件
#        --apply             → plan  ：逐条打印"将要删除什么"，依然不动手
#        --apply --yes       → run   ：真正执行 rm -f（每一项先过两道闸）
#   ② 逐项过闸
#        guard()         拦截 .db/.sqlite/webui.json/config/_home/.venv 等关键对象
#        archive_guard() 在 guard 之上再拦归档包（后缀/黑名单/软链/普通文件/超期）
#   ③ 只清内容
#        只对"普通文件"执行 rm -f；从不 rm -rf，从不删缓存目录本身
#   ④ 静默跳过
#        目标不存在（插件目录 / 缓存目录 / 下载目录）时直接跳过，
#        不报错、不打印空段落、不刷冗余日志
#
# 守护模式
#   --loop 启动循环；pid 锁（默认 /tmp/clean_daemon.pid）保证同一时刻只有一份在跑；
#   默认间隔 7200 秒；--loop 本身不改变模式（要真删必须显式带 --apply --yes）。
#
# 兼容性
#   仅使用 POSIX sh 语法（无 [[ ]]、无数组、无 echo -e、无 $'...'），
#   在 Android Proot 的 Debian/dash 下可直接运行。
#
# 用法
#   sh clean_daemon.sh                        # 报告（默认）
#   sh clean_daemon.sh --apply                # 演练
#   sh clean_daemon.sh --apply --yes          # 真删
#   sh clean_daemon.sh --loop --apply --yes   # 守护：每 7200 秒真删一轮
#   sh clean_daemon.sh --loop                 # 守护：每 7200 秒只报告
#   sh clean_daemon.sh --interval=600         # 自定义循环间隔（秒，最小 1，建议 ≥60）
#   sh clean_daemon.sh -h                     # 查看本帮助
#
# 环境变量
#   CLEAN_ROOT=/root                          # 容器内根（换根可做隔离测试）
#   STORAGE_DOWNLOAD=/storage/emulated/0/Download
#   KEEP_DAYS=3                               # 媒体缓存保留天数
#   LOG_CAP_MB=5                              # 单个日志上限
#   CLEAN_INTERVAL=7200                       # 守护间隔（秒，最小 1）
#   ARCHIVE_KEEP_MIN=60                       # 下载包超期分钟数
#   ARCHIVE_MAX_DEPTH=1                       # 下载包扫描深度（1=只扫根层）
#   PKG_MIN_MB=20                             # 包管理器缓存触发阈值
#   CLEAN_PID=/tmp/clean_daemon.pid           # pid 锁路径
#   CLEAN_LOG=/root/.clean_daemon.log         # 清理日志
# =============================================================================
set -u

# ---------------------------------------------------------------------------
# 基础配置（全部可被环境变量覆盖，便于容器内换根测试）
# ---------------------------------------------------------------------------
APP_HOME="${CLEAN_ROOT:-/root}"                                   # 容器根目录
STORAGE_DOWNLOAD="${STORAGE_DOWNLOAD:-/storage/emulated/0/Download}"
LOG="${CLEAN_LOG:-$APP_HOME/.clean_daemon.log}"                   # 清理记录
PID_FILE="${CLEAN_PID:-/tmp/clean_daemon.pid}"                    # 守护 pid 锁
KEEP_DAYS="${KEEP_DAYS:-3}"                                       # 媒体保留天数
LOG_CAP_MB="${LOG_CAP_MB:-5}"                                     # 日志上限 MB
INTERVAL="${CLEAN_INTERVAL:-7200}"                                # 守护间隔秒
ARCHIVE_KEEP_MIN="${ARCHIVE_KEEP_MIN:-60}"                        # 归档超期分钟
ARCHIVE_MAX_DEPTH="${ARCHIVE_MAX_DEPTH:-1}"                       # 归档扫描深度
PKG_MIN_MB="${PKG_MIN_MB:-20}"                                    # 包缓存阈值 MB
CACHE_MIN_MB="${CACHE_MIN_MB:-0}"                                 # 媒体缓存阈值（0=不限）

# 数字型入参兜底：写错不该让脚本在数值比较处崩掉
num_or() { case "${1:-}" in ''|*[!0-9]*) printf '%s' "$2" ;; *) printf '%s' "$1" ;; esac; }
KEEP_DAYS=$(num_or "$KEEP_DAYS" 3)
LOG_CAP_MB=$(num_or "$LOG_CAP_MB" 5)
INTERVAL=$(num_or "$INTERVAL" 7200)
[ "$INTERVAL" -ge 1 ] || INTERVAL=60
ARCHIVE_KEEP_MIN=$(num_or "$ARCHIVE_KEEP_MIN" 60)
ARCHIVE_MAX_DEPTH=$(num_or "$ARCHIVE_MAX_DEPTH" 1)
[ "$ARCHIVE_MAX_DEPTH" -ge 1 ] || ARCHIVE_MAX_DEPTH=1
PKG_MIN_MB=$(num_or "$PKG_MIN_MB" 20)
CACHE_MIN_MB=$(num_or "$CACHE_MIN_MB" 0)

# ---------------------------------------------------------------------------
# 参数解析
#   注意：--yes 必须与 --apply 同时出现，单独 --yes 直接拒绝，
#         避免"以为在演练、其实在真删"的经典事故。
# ---------------------------------------------------------------------------
MODE="report"
LOOP=0
SAW_APPLY=0
SAW_YES=0

for _arg in "$@"; do
  case "$_arg" in
    --apply)      SAW_APPLY=1; MODE="plan" ;;
    --yes)        SAW_YES=1;   MODE="run" ;;
    --report)     MODE="report" ;;
    --loop)       LOOP=1 ;;
    --interval=*) INTERVAL=$(num_or "${_arg#*=}" 7200)
                  [ "$INTERVAL" -ge 1 ] || INTERVAL=60 ;;
    -h|--help)
      awk 'NR>1 && /^#/ {sub(/^# ?/,""); print; next} NR>1 {exit}' "$0"
      exit 0 ;;
    *)
      printf '[WARN] 未知参数: %s\n' "$_arg" >&2
      printf '用法: %s [--apply] [--yes] [--loop] [--interval=秒] [-h]\n' "$0" >&2
      exit 2 ;;
  esac
done

if [ "$SAW_YES" = "1" ] && [ "$SAW_APPLY" = "0" ]; then
  printf '[WARN] 拒绝执行：--yes 必须与 --apply 同时使用\n' >&2
  printf '       sh %s --apply            # 先演练\n' "$0" >&2
  printf '       sh %s --apply --yes      # 确认无误后再真删\n' "$0" >&2
  exit 2
fi

# ---------------------------------------------------------------------------
# 输出与日志
#   report 模式不写日志文件（保持"只读"的纯粹性）；
#   plan/run 追加到 $LOG，并做自限流，避免守卫自己的日志无限长。
# ---------------------------------------------------------------------------
say() {
  _line="[$(date '+%Y-%m-%d %H:%M:%S')] $*"
  printf '%s\n' "$_line"
  if [ "$MODE" != "report" ]; then
    printf '%s\n' "$_line" >>"$LOG" 2>/dev/null
    if [ -f "$LOG" ]; then
      _sz=$(stat -c %s "$LOG" 2>/dev/null || printf '0')
      if [ "${_sz:-0}" -gt 1048576 ]; then
        tail -c 200000 "$LOG" >"$LOG.tmp" 2>/dev/null && mv -f "$LOG.tmp" "$LOG" 2>/dev/null
      fi
    fi
  fi
}
safe() { printf '[SAFE] %s\n' "$*"; }
warn() { printf '[WARN] %s\n' "$*" >&2; }

# ---------------------------------------------------------------------------
# 闸门 ①：guard()
#
# 规则按"路径段"判断，而不是简单子串包含——原因很实际：
# NapCat 的媒体缓存真实路径是
#     /root/napcat_instances/qq1_xxx_home/.../nt_data/Pic/a.jpg
# 整条路径都"包含 _home"。若纯子串拒绝，第 1 类目标将完全无法工作。
# 因此这里拦截的是"关键对象本身"：
#   ① 扩展名：数据库 / 配置 / 令牌 / 环境文件
#   ② 最后一段：_home / config / .venv / data / plugins
#   ③ 关键子系统：AstrBot/data、*_home 配置目录
# 需要"任何子串都拒绝"的极严模式时，设 STRICT_GUARD=1
# （代价是第 1 类媒体清理会整体跳过，用于宁可不清也不能错的场景）。
# ---------------------------------------------------------------------------
STRICT_GUARD="${STRICT_GUARD:-0}"

guard() {
  _p="${1:-}"
  [ -n "$_p" ] || return 1

  # ① 扩展名级：数据库 / 配置 / 令牌 / 环境文件，任何情况下都不碰
  case "$_p" in
    *.db|*.db-*|*.db.wal|*.db-shm|*.db-journal) return 1 ;;
    *.sqlite|*.sqlite3|*.sqlite-*|*.sqlite3-*) return 1 ;;
    *webui.json|*config.json|*cmd_config.json|*.yaml|*.yml|*.toml|*.env|*.token|*/.napcat_qq) return 1 ;;
  esac

  # ② 关键目录本身（最后一段）绝不作为删除目标
  _base=$(basename "$_p")
  case "$_base" in
    _home|config|.venv|data|plugins|plugin_data) return 1 ;;
    ''|.|..) return 1 ;;
  esac

  # ③ 关键子系统路径：登录态、AstrBot 数据目录本身、虚拟环境
  #    注意：只拦 AstrBot/data 这个"目录本身"。插件缓存位于
  #    AstrBot/data/plugin_data/<插件>/memes 之类的位置，第 2 类目标要清的就是它，
  #    因此不能把 /AstrBot/data/ 下的所有路径一律拒绝。
  #    里面的数据库/配置由 ① 的扩展名规则单独拦住。
  case "$_p" in
    */AstrBot/data|*/astrbot/data) return 1 ;;
    */.venv|*/.venv/*) return 1 ;;
    */napcat_instances/*/_home) return 1 ;;
    */napcat_instances/*/_home/*/config|*/napcat_instances/*/_home/*/config/*) return 1 ;;
  esac

  # ④ 极严模式（可选）：任何子串命中都拒绝
  if [ "$STRICT_GUARD" = "1" ]; then
    case "$_p" in
      *_home*|*config*|*.db*|*.sqlite*) return 1 ;;
    esac
  fi

  return 0
}

# ---------------------------------------------------------------------------
# 闸门 ②：archive_guard()
# 只放行"看起来就是临时下载"的归档包，六道检查缺一不可：
#   后缀 → 文件名黑名单 → 路径黑名单 → guard() → 非软链+普通文件 → 确实超期
# ---------------------------------------------------------------------------
archive_guard() {
  _p="${1:-}"
  [ -n "$_p" ] || return 1

  # ① 后缀白名单：只处理这两种
  case "$_p" in
    *.tar.zst|*.zip) ;;
    *) return 1 ;;
  esac

  # ② 文件名黑名单：备份 / 插件 / 组件包 / 配置，一律视为"可能有价值"
  _b=$(basename "$_p")
  case "$_b" in
    *backup*|*Backup*|*BACKUP*) return 1 ;;
    *AstrBotBubble*|*AstrBot-android-lua*) return 1 ;;
    *plugin*|*Plugin*|*config*|*Config*) return 1 ;;
    ''|.|..) return 1 ;;
  esac

  # ③ 路径黑名单：安装目录 / 登录态 / 虚拟环境 / 缓存内部，一律不下钻
  case "$_p" in
    */AstrBot/*|*/astrbot/*|*/napcat_instances/*|*/.venv/*|*/.cache/*|*/data/*|*/plugin_data/*) return 1 ;;
  esac

  # ④ 原有 guard() 的全部规则
  guard "$_p" || return 1

  # ⑤ 必须是普通文件，且不是符号链接（软链一律不跟、不删）
  [ -h "$_p" ] && return 1
  [ -f "$_p" ] || return 1

  # ⑥ 必须真的超期：-mmin +N 成立才放行
  [ -n "$(find "$_p" -maxdepth 0 -mmin +"$ARCHIVE_KEEP_MIN" 2>/dev/null)" ]
}

# ---------------------------------------------------------------------------
# 删除动作：只删文件
#   - 永远 rm -f，永不 rm -rf，永不删目录
#   - 每次删除前打印 [WARN]（演练/真删）或 [SAFE]（报告）
# ---------------------------------------------------------------------------
del_file() {
  _p="${1:-}"
  [ -f "$_p" ] || return 0

  # 符号链接：不跟、不删
  if [ -h "$_p" ]; then
    say "    [SKIP] 符号链接不处理: $_p"
    return 0
  fi

  # 过闸：任何一项不通过就跳过并留痕
  if ! guard "$_p"; then
    say "    [SKIP] guard 拒绝（受保护对象）: $_p"
    return 0
  fi

  _sz=$(du -k "$_p" 2>/dev/null | awk '{print $1}')

  case "$MODE" in
    report) say "    [SAFE] 可清理: $_p (${_sz:-?}KB)" ;;
    plan)   say "    [WARN] 将删除: $_p (${_sz:-?}KB)" ;;
    run)
      if rm -f "$_p" 2>/dev/null; then
        say "    [WARN] 已删除: $_p (${_sz:-?}KB)"
      else
        say "    [SKIP] 删除失败（权限/占用）: $_p"
      fi
      ;;
  esac
}

# ---------------------------------------------------------------------------
# 清一个缓存目录里的"文件"
#   只删普通文件（含子目录里的文件），目录骨架一律保留；
#   $3 = 触发阈值 MB（0 表示不看体积，直接扫）
# ---------------------------------------------------------------------------
clean_dir_files() {
  _d="${1:-}"; _label="${2:-cache}"; _min=$(num_or "${3:-$CACHE_MIN_MB}" 0)
  [ -d "$_d" ] || return 0

  _mb=$(du -sm "$_d" 2>/dev/null | awk '{print $1}')
  if [ "$_min" -gt 0 ] && [ "${_mb:-0}" -lt "$_min" ]; then
    return 0
  fi

  say "  [$_label] $_d = ${_mb:-?}MB"

  # 时间条件：KEEP_DAYS=0 表示不限新旧（全量候选）
  if [ "$KEEP_DAYS" -gt 0 ]; then
    find "$_d" -type f -mtime +"$KEEP_DAYS" 2>/dev/null | while IFS= read -r _f; do
      del_file "$_f"
    done
  else
    find "$_d" -type f 2>/dev/null | while IFS= read -r _f; do
      del_file "$_f"
    done
  fi
}

# ---------------------------------------------------------------------------
# 1) NapCat 媒体缓存
#    只在 nt_data / cache / temp 这三类路径下，找 Pic/Image/Video/Ptt/Record，
#    保留最近 KEEP_DAYS 天（默认 3 天）。
# ---------------------------------------------------------------------------
clean_napcat_media() {
  say "== 1) NapCat 媒体缓存（Pic/Image/Video/Ptt/Record，保留 ${KEEP_DAYS} 天）"
  _base="$APP_HOME/napcat_instances"
  if [ ! -d "$_base" ]; then
    say "  跳过（无 $_base）"
    return 0
  fi

  for _home in "$_base"/*_home; do
    [ -d "$_home" ] || continue
    _name=$(basename "$_home")           # acc1_home
    _name=${_name%_home}                  # → acc1（只用于日志标签）

    # 找出所有媒体目录，再按路径过滤到缓存区（避免误伤业务目录）
    find "$_home" -type d \
      \( -iname 'Pic' -o -iname 'Image' -o -iname 'Video' \
         -o -iname 'Ptt' -o -iname 'Record' \) 2>/dev/null | while IFS= read -r _d; do
        case "$_d" in
          *nt_data*|*cache*|*Cache*|*temp*|*Temp*)
            clean_dir_files "$_d" "$_name/media" ;;
        esac
      done
  done
}

# ---------------------------------------------------------------------------
# 2) 表情包小偷 / 插件缓存
# ---------------------------------------------------------------------------
clean_stealer() {
  # 找不到插件目录时【静默跳过】：不报错、不打印段落标题、不刷任何日志。
  # 因此段落标题延迟到"第一个真实存在的 stealer 目录"出现时才打印。
  _hdr=0
  for _base in "$APP_HOME/AstrBot/data/plugin_data" "$APP_HOME/astrbot/data/plugin_data"; do
    if [ -d "$_base" ]; then
      for _pd in "$_base"/*stealer*; do
        if [ -d "$_pd" ]; then
          if [ "$_hdr" -eq 0 ]; then
            say "== 2) 表情包小偷 / 插件缓存（plugin_data/*stealer*/ 下的 memes/images/pics）"
            _hdr=1
          fi
          say "  插件目录: $(basename "$_pd")"
          # 只清真正存在的缓存子目录
          for _sub in memes images pics cache data/images data/memes temp; do
            if [ -d "$_pd/$_sub" ]; then
              clean_dir_files "$_pd/$_sub" "stealer/$_sub"
            fi
          done
        fi
      done
    fi
  done
  return 0
}

# ---------------------------------------------------------------------------
# 3) 包管理器缓存（apt / pip / uv / npm）
#    仅当目录超过 PKG_MIN_MB（默认 20MB）才触发；只删文件，保留目录结构。
#    逐文件扫描代价太大，改为"整目录 -exec rm -f"，但先过：
#      - 目录本身过 guard()
#      - 排除数据库/配置类文件（! -name 过滤）
# ---------------------------------------------------------------------------
clean_pkg_cache() {
  say "== 3) 包管理器缓存（≥${PKG_MIN_MB}MB 才触发，内容全可再生）"
  for _d in /var/cache/apt/archives \
            "$APP_HOME/.cache/pip" "$APP_HOME/.cache/uv" \
            /tmp/uv-cache "$APP_HOME/.npm/_cacache"; do
    [ -d "$_d" ] || continue
    guard "$_d" || { say "  [SKIP] guard 拒绝: $_d"; continue; }

    _mb=$(du -sm "$_d" 2>/dev/null | awk '{print $1}')
    [ "${_mb:-0}" -ge "$PKG_MIN_MB" ] || continue

    _n=$(find "$_d" -type f 2>/dev/null | wc -l | tr -d ' ')
    case "$MODE" in
      report) say "  [SAFE] $_d = ${_mb}MB / ${_n} 个文件（超过 ${PKG_MIN_MB}MB 阈值，报告模式不动手）" ;;
      plan)   say "  [WARN] 将清空 $_d 下 ${_n} 个文件（演练，不删）" ;;
      run)
        say "  [WARN] 清空 $_d（${_mb}MB / ${_n} 个文件），保留目录本身"
        find "$_d" -type f \
          ! -name '*.db' ! -name '*.db-*' ! -name '*.sqlite*' \
          ! -name 'webui.json' ! -name '*.yaml' ! -name '*.yml' \
          -exec rm -f {} + 2>/dev/null
        say "  [WARN] 已清空 $_d 的普通文件"
        ;;
    esac
  done
}

# ---------------------------------------------------------------------------
# 4) 日志限流：超过 LOG_CAP_MB（默认 5MB）就截断
#    truncate 保留文件头部；没有 truncate 时退回 head -c + mv
# ---------------------------------------------------------------------------
cap_log() {
  _f="${1:-}"
  [ -f "$_f" ] || return 0
  [ -h "$_f" ] && return 0

  _sz=$(stat -c %s "$_f" 2>/dev/null || printf '0')
  _lim=$((LOG_CAP_MB * 1024 * 1024))
  [ "${_sz:-0}" -gt "$_lim" ] || return 0

  _mb=$((_sz / 1024 / 1024))
  case "$MODE" in
    report) say "  [SAFE] 日志超限: $_f (${_mb}MB → ${LOG_CAP_MB}MB，报告模式不截断)" ;;
    plan)   say "  [WARN] 将截断: $_f (${_mb}MB → ${LOG_CAP_MB}MB，演练)" ;;
    run)
      if command -v truncate >/dev/null 2>&1; then
        if truncate -s "${LOG_CAP_MB}M" "$_f" 2>/dev/null; then
          say "  [WARN] 已截断: $_f (${_mb}MB → ${LOG_CAP_MB}MB)"
        else
          say "  [SKIP] 截断失败: $_f"
        fi
      else
        # 退化路径：保留头部 LOG_CAP_MB 大小
        if head -c "$((LOG_CAP_MB * 1024 * 1024))" "$_f" >"$_f.tmp" 2>/dev/null; then
          mv -f "$_f.tmp" "$_f" 2>/dev/null && say "  [WARN] 已截断(退化): $_f"
        else
          rm -f "$_f.tmp" 2>/dev/null
          say "  [SKIP] 截断失败: $_f"
        fi
      fi
      ;;
  esac
}

clean_logs() {
  say "== 4) 日志限流（单个文件上限 ${LOG_CAP_MB}MB）"
  # 容器根下的 *.log（astrbot.log / napcat.log / ollama.log 等）
  for _f in "$APP_HOME"/*.log; do
    [ -f "$_f" ] || continue
    cap_log "$_f"
  done
  # 常见临时日志
  for _f in /tmp/http_trigger.log /tmp/token_sync.log /tmp/stack_boot.log; do
    cap_log "$_f"
  done
}

# ---------------------------------------------------------------------------
# 5) 临时下载包
#    /root/ 与 /storage/emulated/0/Download/ 下，超过 ARCHIVE_KEEP_MIN（默认 60）
#    分钟未修改的 *.tar.zst / *.zip；逐项必须通过 archive_guard。
#    默认只扫根层（ARCHIVE_MAX_DEPTH=1），避免钻进安装目录。
# ---------------------------------------------------------------------------
clean_tmp_archives() {
  say "== 5) 临时下载包（*.tar.zst / *.zip，超过 ${ARCHIVE_KEEP_MIN} 分钟未修改，深度 ${ARCHIVE_MAX_DEPTH}）"
  _total=0

  for _d in "$APP_HOME" "$STORAGE_DOWNLOAD"; do
    if [ ! -d "$_d" ]; then
      say "  跳过（目录不存在）: $_d"
      continue
    fi

    _n=$(find "$_d" -maxdepth "$ARCHIVE_MAX_DEPTH" -type f \
           \( -name '*.tar.zst' -o -name '*.zip' \) \
           -mmin +"$ARCHIVE_KEEP_MIN" 2>/dev/null | wc -l | tr -d ' ')
    say "  $_d: 命中 ${_n:-0} 个候选"
    _total=$((_total + ${_n:-0}))

    find "$_d" -maxdepth "$ARCHIVE_MAX_DEPTH" -type f \
      \( -name '*.tar.zst' -o -name '*.zip' \) \
      -mmin +"$ARCHIVE_KEEP_MIN" 2>/dev/null | while IFS= read -r _f; do
        if archive_guard "$_f"; then
          del_file "$_f"
        else
          say "    [SKIP] archive_guard 拒绝（备份/插件/组件/软链/未超期）: $_f"
        fi
      done
  done

  [ "$_total" -eq 0 ] && say "  没有超期的临时下载包"
  return 0
}

# ---------------------------------------------------------------------------
# 6) 磁盘体检
# ---------------------------------------------------------------------------
report() {
  say "== 6) 磁盘体检"
  say "  占用 Top 8（$APP_HOME）:"
  du -sm "$APP_HOME"/* 2>/dev/null | sort -rn | head -8 | while IFS= read -r _line; do
    say "    $_line"
  done

  if [ -d "$STORAGE_DOWNLOAD" ]; then
    _dmb=$(du -sm "$STORAGE_DOWNLOAD" 2>/dev/null | awk '{print $1}')
    say "  下载目录: ${_dmb:-?}MB  $STORAGE_DOWNLOAD"
  fi

  _df=$(df -h "$APP_HOME" 2>/dev/null | awk 'NR==2{print $5" 已用 / "$4" 可用"}')
  say "  磁盘: ${_df:-未知}"
}

# ---------------------------------------------------------------------------
# 单轮：六件事，顺序固定
# ---------------------------------------------------------------------------
one_pass() {
  say "===== 开始 [模式=$MODE 保留=${KEEP_DAYS}天 归档=${ARCHIVE_KEEP_MIN}分] ====="
  clean_napcat_media
  clean_stealer
  clean_pkg_cache
  clean_logs
  clean_tmp_archives
  report
  say "===== 结束 ====="
}

# ---------------------------------------------------------------------------
# 守护模式：pid 锁 + 循环
#   锁的意义：boot_services.sh / 界面按钮 / 手工命令三方都可能拉起守护，
#   没有锁就会同时跑多份，互相删到对方正在处理的文件。
# ---------------------------------------------------------------------------
cleanup_lock() {
  _cur=$(cat "$PID_FILE" 2>/dev/null || printf '')
  [ "$_cur" = "$$" ] && rm -f "$PID_FILE" 2>/dev/null
  return 0
}

lock_acquire() {
  if [ -f "$PID_FILE" ]; then
    _old=$(cat "$PID_FILE" 2>/dev/null || printf '')
    # 注意：启动器（boot_services.sh）可能先写了一次 pid 文件，里面就是"我自己的 pid"。
    # 这种情况不能误判成"已有实例"，否则守护每次都会被自己的锁挡在门外。
    if [ -n "$_old" ] && [ "$_old" != "$$" ] && kill -0 "$_old" 2>/dev/null; then
      warn "已有守护在运行（pid $_old），本次直接退出: $PID_FILE"
      exit 0
    fi
    warn "发现残留 pid 文件（pid ${_old:-?} 已不存在），接管并继续"
    rm -f "$PID_FILE" 2>/dev/null
  fi
  if ! printf '%s\n' "$$" >"$PID_FILE" 2>/dev/null; then
    warn "无法写入 pid 锁: $PID_FILE（换个路径可设 CLEAN_PID=...）"
    exit 1
  fi
  trap 'cleanup_lock' 0
  trap 'cleanup_lock; exit 0' 1 2 15
}

# ---------------------------------------------------------------------------
# 启动横幅：把"这一轮到底会不会删东西"说清楚
# ---------------------------------------------------------------------------
banner() {
  printf '\n'
  case "$MODE" in
    report) safe "模式=report（只读）：不删除、不截断、不修改任何文件" ;;
    plan)   warn "模式=plan（演练）：逐条打印将要删除的文件，但不会真的删除" ;;
    run)    warn "模式=run（真删）：将执行 rm -f；每一项都会先过 guard()/archive_guard()" ;;
  esac
  printf '       根目录=%s  下载目录=%s\n' "$APP_HOME" "$STORAGE_DOWNLOAD"
  printf '       日志=%s  锁=%s\n' "$LOG" "$PID_FILE"
  printf '\n'
}

if [ "$LOOP" = "1" ] && [ "$MODE" = "report" ]; then
  safe "守护模式但未指定 --apply --yes：每 ${INTERVAL}s 只做报告，不会删除任何文件"
  safe "要让它真正清理：sh $0 --loop --apply --yes"
fi

banner

if [ "$LOOP" = "1" ]; then
  lock_acquire
  say "[WARN] 守护启动：pid $$，间隔 ${INTERVAL}s，模式 $MODE"
  while :; do
    one_pass
    # 用后台 sleep + wait，让 TERM 能立刻打断等待
    sleep "$INTERVAL" &
    wait $!
  done
else
  one_pass
fi

exit 0
