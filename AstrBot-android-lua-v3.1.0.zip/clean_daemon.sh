#!/bin/sh
# =============================================================================
# clean_daemon.sh —— v2.3.0 磁盘守卫（默认 dry-run，每 2 小时一次）
#
# 三重保险：
#   1. 不加 --apply 只报告，不动手；加 --apply 还要再加 --yes 才真删
#   2. 删除前逐项过 guard() / archive_guard()：任何 .db/.sqlite/配置/webui.json 一律跳过
#   3. 只清"缓存目录的内容"，目录本身、_home 根、登录态一律不碰
#
# v2.3.0 新增第 5 类：临时下载包
#   /root/ 与 /storage/emulated/0/Download/ 下，超过 ARCHIVE_KEEP_MIN（默认 60）
#   分钟未修改的 *.tar.zst / *.zip。逐项过 archive_guard()：备份包、插件包、
#   组件包、AstrBot/napcat_instances/.venv 路径、符号链接一律拒绝。
#
# 用法：
#   sh clean_daemon.sh                     # 报告（默认）
#   sh clean_daemon.sh --apply             # 演练删除（逐条打印，不执行）
#   sh clean_daemon.sh --apply --yes       # 真正删除
#   sh clean_daemon.sh --loop              # 每 7200 秒自动 --apply --yes
#
# 可调环境变量：
#   CLEAN_ROOT=/root  STORAGE_DOWNLOAD=/storage/emulated/0/Download
#   KEEP_DAYS=3  LOG_CAP_MB=5  CLEAN_INTERVAL=7200
#   ARCHIVE_KEEP_MIN=60  ARCHIVE_MAX_DEPTH=1
# =============================================================================
set -u

ROOT="${CLEAN_ROOT:-/root}"
LOG="$ROOT/.clean_daemon.log"
KEEP_DAYS="${KEEP_DAYS:-3}"        # 缓存文件保留最近几天；0=全清
LOG_CAP_MB="${LOG_CAP_MB:-5}"      # 日志上限 5MB
INTERVAL="${CLEAN_INTERVAL:-7200}" # 2 小时
# v2.3.0：临时下载包
STORAGE_DOWNLOAD="${STORAGE_DOWNLOAD:-/storage/emulated/0/Download}"
ARCHIVE_KEEP_MIN="${ARCHIVE_KEEP_MIN:-60}"   # 超过多少分钟未修改才清（1 小时）
ARCHIVE_MAX_DEPTH="${ARCHIVE_MAX_DEPTH:-1}"  # 1=只扫根层；想递归改成 2/3（守卫仍生效）
case "$ARCHIVE_KEEP_MIN" in ''|*[!0-9]*) ARCHIVE_KEEP_MIN=60 ;; esac
case "$ARCHIVE_MAX_DEPTH" in ''|*[!0-9]*) ARCHIVE_MAX_DEPTH=1 ;; esac
case "$KEEP_DAYS" in ''|*[!0-9]*) KEEP_DAYS=3 ;; esac

MODE="report"      # report | plan | run
for a in "$@"; do
  case "$a" in
    --apply) MODE="plan" ;;
    --yes)   MODE="run" ;;
    --loop)  MODE="run"; LOOP=1 ;;
    -h|--help) awk 'NR>1 && /^#/ {sub(/^# ?/,""); print; next} NR>1 {exit}' "$0"; exit 0 ;;
  esac
done
LOOP="${LOOP:-0}"

# ---------- 日志 ----------
say() {
  line="[$(date '+%m-%d %H:%M:%S')] $*"
  echo "$line"
  [ "$MODE" = "report" ] || echo "$line" >> "$LOG" 2>/dev/null
  # 守卫自己的日志也不能无限长
  if [ -f "$LOG" ] && [ "$(stat -c %s "$LOG" 2>/dev/null || echo 0)" -gt 1048576 ]; then
    tail -c 200000 "$LOG" > "$LOG.t" 2>/dev/null && mv "$LOG.t" "$LOG"
  fi
}

# ---------- 安全闸门：任何命中以下模式的路径，一律拒绝 ----------
guard() {
  p="$1"
  case "$p" in
    *.db|*.db-*|*.sqlite|*.sqlite3|*.sqlite-*|*.sqlite3-*) return 1 ;;
    *webui.json|*config.json|*.yaml|*.yml|*.toml|*.env|*.token|*/.napcat_qq) return 1 ;;
    */_home) return 1 ;;            # 登录态与聊天记录根目录，绝对不删
    */AstrBot/data) return 1 ;;
  esac
  return 0
}

do_del() {   # do_del <路径>   只删文件/内容，目录本身保留
  p="$1"
  guard "$p" || { say "    ⛔ 拒绝（受保护类型）: $p"; return 0; }
  case "$MODE" in
    report) say "    [待清] $p" ;;
    plan)   say "    [演练] 将删除 $p" ;;
    run)    rm -rf "$p" 2>/dev/null && say "    [已删] $p" ;;
  esac
}

# 清空一个缓存目录的"内容"（目录本身保留；逐个过 guard）
clean_dir_contents() {
  d="$1"; label="$2"
  [ -d "$d" ] || return 0
  mb=$(du -sm "$d" 2>/dev/null | awk '{print $1}')
  [ "${mb:-0}" -ge 5 ] || return 0
  say "  $label ($d) = ${mb}MB"
  if [ "$KEEP_DAYS" -gt 0 ]; then
    find "$d" -mindepth 1 -maxdepth 1 -mtime +"$KEEP_DAYS" 2>/dev/null | while read -r x; do
      do_del "$x"
    done
  else
    find "$d" -mindepth 1 -maxdepth 1 2>/dev/null | while read -r x; do
      do_del "$x"
    done
  fi
}

# ---------- 1. NapCat 聊天附件缓存（image/video/ptt） ----------
clean_napcat_media() {
  say "== 1) NapCat 媒体缓存（image / video / ptt，保留最近 ${KEEP_DAYS} 天）"
  [ -d "$ROOT/napcat_instances" ] || { say "  无 napcat_instances"; return; }
  for home in "$ROOT"/napcat_instances/*_home; do
    [ -d "$home" ] || continue
    base=$(basename "$(dirname "$home")")
    # QQ NT 的附件缓存常见落点
    for pat in Pic Image image Video video Ptt ptt Record record; do
      find "$home" -type d -iname "$pat" 2>/dev/null | while read -r d; do
        # 只认 nt_data / cache / temp 这些缓存路径，避免误伤业务目录
        case "$d" in
          *nt_data*|*cache*|*Cache*|*temp*|*Temp*) clean_dir_contents "$d" "$base" ;;
        esac
      done
    done
    # NapCat 自己的实例缓存（二维码等）
    clean_dir_contents "$(dirname "$home")/${base}/cache" "$base/napcat-cache"
    clean_dir_contents "$(dirname "$home")/${base}/logs"  "$base/napcat-logs"
  done
}

# ---------- 2. AstrBot 表情包小偷缓存 ----------
clean_stealer() {
  say "== 2) 表情包小偷 / 插件缓存"
  for base in "$ROOT/AstrBot/data/plugin_data" "$ROOT/astrbot/data/plugin_data"; do
    [ -d "$base" ] || continue
    for pd in "$base"/*stealer*; do
      [ -d "$pd" ] || continue
      say "  插件目录: $(basename "$pd")"
      for sub in memes images pics cache data/images data/memes temp; do
        [ -d "$pd/$sub" ] && clean_dir_contents "$pd/$sub" "stealer/$sub"
      done
    done
  done
}

# ---------- 3. 包管理器缓存 ----------
clean_pkg_cache() {
  say "== 3) apt / pip / uv 缓存（全可再生）"
  for d in /var/cache/apt/archives /root/.cache/pip /root/.cache/uv /tmp/uv-cache /root/.npm/_cacache; do
    [ -d "$d" ] || continue
    mb=$(du -sm "$d" 2>/dev/null | awk '{print $1}')
    [ "${mb:-0}" -ge 20 ] || continue
    say "  $d = ${mb}MB"
    case "$MODE" in
      report) say "    [待清] $d/*" ;;
      plan)   say "    [演练] 将清空 $d/*" ;;
      run)    rm -rf "$d"/* 2>/dev/null && say "    [已清] $d/*" ;;
    esac
  done
}

# ---------- 4. 日志压到 5MB ----------
cap_log() {
  f="$1"
  [ -f "$f" ] || return 0
  sz=$(stat -c %s "$f" 2>/dev/null || echo 0)
  [ "$sz" -gt $((LOG_CAP_MB * 1024 * 1024)) ] || return 0
  say "  日志超限: $f ($((sz / 1024 / 1024))MB) → ${LOG_CAP_MB}MB"
  case "$MODE" in
    report) say "    [待截断] $f" ;;
    plan)   say "    [演练] truncate -s ${LOG_CAP_MB}M $f" ;;
    run)    truncate -s "${LOG_CAP_MB}M" "$f" 2>/dev/null && say "    [已截断] $f" ;;
  esac
}

clean_logs() {
  say "== 4) 日志限流（上限 ${LOG_CAP_MB}MB）"
  for f in "$ROOT/astrbot.log" "$ROOT/napcat.log" "$ROOT/ollama.log" \
           /tmp/http_trigger.log /tmp/token_sync.log /tmp/stack_boot.log; do
    cap_log "$f"
  done
}

# =============================================================================
# 5. v2.3.0 · 临时下载包（*.tar.zst / *.zip）
#
# 比 guard() 更严：只放行"看起来就是临时下载"的归档，任何可能承载数据的
# 名字/路径都不碰。逐项校验顺序：
#   后缀 → 文件名黑名单 → 路径黑名单 → guard() → 普通文件（非符号链接）
#   → 确实超过 ARCHIVE_KEEP_MIN 分钟未修改
# =============================================================================
archive_guard() {
  p="$1"
  [ -n "$p" ] || return 1
  # ① 只处理这两种后缀
  case "$p" in
    *.tar.zst|*.zip) ;;
    *) return 1 ;;
  esac
  # ② 文件名黑名单：备份 / 插件 / 组件包 / 配置，一律视为"可能有价值"
  case "$(basename "$p")" in
    *backup*|*Backup*|*BACKUP*|*AstrBotBubble*|*AstrBot-android-lua*|*plugin*|*Plugin*|*config*|*Config*) return 1 ;;
    ''|.|..|*/*) return 1 ;;
  esac
  # ③ 路径黑名单：安装目录、登录态、虚拟环境、缓存内部绝不下钻
  case "$p" in
    */AstrBot/*|*/astrbot/*|*/napcat_instances/*|*/.venv/*|*/.cache/*|*/data/*) return 1 ;;
  esac
  # ④ 原有 guard() 保护类型
  guard "$p" || return 1
  # ⑤ 必须是普通文件，符号链接不删
  [ -f "$p" ] || return 1
  [ -h "$p" ] && return 1
  # ⑥ 必须真的超期（分钟）
  [ -n "$(find "$p" -maxdepth 0 -mmin +"$ARCHIVE_KEEP_MIN" 2>/dev/null)" ]
}

del_archive() {   # 只删单个归档文件，rm -f 不递归
  p="$1"
  if ! archive_guard "$p"; then
    say "    ⛔ 拒绝（受保护 / 未超期 / 非普通文件）: $p"
    return 0
  fi
  sz=$(du -k "$p" 2>/dev/null | awk '{print $1}')
  case "$MODE" in
    report) say "    [待清] $p (${sz:-?}KB)" ;;
    plan)   say "    [演练] 将删除 $p (${sz:-?}KB)" ;;
    run)    rm -f "$p" 2>/dev/null && say "    [已删] $p (${sz:-?}KB)" ;;
  esac
}

clean_tmp_archives() {
  say "== 5) 临时下载包（*.tar.zst / *.zip，超过 ${ARCHIVE_KEEP_MIN} 分钟未修改，深度 ${ARCHIVE_MAX_DEPTH}）"
  _hit=0
  for d in "$ROOT" "$STORAGE_DOWNLOAD"; do
    if [ ! -d "$d" ]; then
      say "  跳过（目录不存在）: $d"
      continue
    fi
    _n=$(find "$d" -maxdepth "$ARCHIVE_MAX_DEPTH" -type f \
           \( -name '*.tar.zst' -o -name '*.zip' \) -mmin +"$ARCHIVE_KEEP_MIN" 2>/dev/null \
         | wc -l | tr -d ' ')
    say "  $d: 命中 ${_n:-0} 个"
    _hit=$((_hit + ${_n:-0}))
    find "$d" -maxdepth "$ARCHIVE_MAX_DEPTH" -type f \
      \( -name '*.tar.zst' -o -name '*.zip' \) -mmin +"$ARCHIVE_KEEP_MIN" 2>/dev/null \
      | while read -r f; do
          del_archive "$f"
        done
  done
  [ "$_hit" -eq 0 ] && say "  没有超期的临时下载包"
  return 0
}

# ---------- 6. 体检 ----------
report() {
  say "== 6) 占用 Top 8"
  du -sm "$ROOT"/* 2>/dev/null | sort -rn | head -8 | while read -r m p; do
    say "  ${m}MB  $p"
  done
  if [ -d "$STORAGE_DOWNLOAD" ]; then
    say "  下载目录: $(du -sm "$STORAGE_DOWNLOAD" 2>/dev/null | awk '{print $1}')MB  $STORAGE_DOWNLOAD"
  fi
  say "  磁盘: $(df -h "$ROOT" 2>/dev/null | awk 'NR==2{print $5" 已用, "$4" 可用"}')"
}

one_pass() {
  say "===== 开始 [模式=$MODE 缓存保留=${KEEP_DAYS}天 归档超期=${ARCHIVE_KEEP_MIN}分钟] ====="
  clean_napcat_media
  clean_stealer
  clean_pkg_cache
  clean_logs
  clean_tmp_archives
  report
  say "===== 结束 ====="
}

if [ "$LOOP" = "1" ]; then
  say "守护启动，间隔 ${INTERVAL}s"
  while :; do one_pass; sleep "$INTERVAL"; done
else
  one_pass
fi
