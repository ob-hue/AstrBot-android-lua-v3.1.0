-- AstrBot Android 脚本 v3.1.0 (位于 {configPath}/scripts/main.lua, 可直接编辑, 主页顶栏刷新键重载)
-- API 详见同目录 AGENTS.md
--
-- v3.1.0 变更摘要（向量模型动态配置版）:
--   · 状态卡直接显示版本号
--   · 向量模型名不再是常量: 点「模型: xxx（点击修改）」→ host.input → 存 ollama_embed_model
--   · 模型名经环境变量 OLLAMA_MODEL 传给 boot_services.sh（boot_all / 看护 / 手动启停三处）
--   · 改完给 toast + 通知，并在后台用 ollama list 核实模型是否已下载
--
-- v2.3.0 变更摘要:
--   · Ollama 全栈整合: 状态灯 / 一键启动 / WATCH 掉线自动拉起 / 11434 探测
--   · UI 单卡化: 删除 astrbot_card(quick_start_card) 与 napcat_card, 主页只剩一张「全栈状态」卡
--   · 新增【打开 AstrBot WebUI】【打开 NapCat WebUI】快捷入口
--   · QQ 号显示修复: onebot11_<uin>.json / webui.json autoLoginAccount / 日志正则 三路还原真实 UIN

local APP_VERSION = "v3.1.0"

-- 独立 agent 模块 (opencode 引擎: 安装/启动/WebUI 托管), 界面在本文件编排
local agent = require("agent")

-- 端口管理: 纯 Lua, 基于通用设置存储 host.get/set (无 Dart 特定端口逻辑)
local ports = {
  key = { dashboard = "astrbot_dashboard_port", onebot = "astrbot_onebot_ws_port", napcat = "napcat_webui_port" },
  def = { dashboard = 6185, onebot = 6199, napcat = 6099 },
}
function ports.get(name)
  local v = tonumber(host.get(ports.key[name]))
  if v and v >= 1024 and v <= 65535 then return v end
  return ports.def[name]
end
function ports.set(name, v) host.set(ports.key[name], v) end

-- ============================================================
-- v3.1.0 · Ollama 本地向量模型（模型名可配置）
--   端口 11434（与 boot_services.sh 的 OLLAMA_PORT 一致）
--   二进制可能在 PATH，也可能是 App 自带的 /root/.ollama/ollama
--   模型名存 host.get("ollama_embed_model")，界面上点一下就改；
--   拉起/预热统一通过环境变量 OLLAMA_MODEL 传给 boot_services.sh
-- ============================================================
local OLLAMA_DEFAULT_PORT = 11434
local OLLAMA_DEFAULT_MODEL = "nomic-embed-text"
-- 允许字符：字母/数字/- _ . : / +（覆盖 bge-m3、qwen2.5:7b、library/model:tag 这类写法）
local MODEL_NAME_OK = "^[%w%-%._/:+]+$"
local MODEL_NAME_MAX = 120

local function valid_model_name(s)
  return type(s) == "string" and #s >= 1 and #s <= MODEL_NAME_MAX and s:match(MODEL_NAME_OK) ~= nil
end

local function ollama_port()
  local v = tonumber(host.get("ollama_port"))
  if v and v >= 1024 and v <= 65535 then return v end
  return OLLAMA_DEFAULT_PORT
end

-- 读模型名：先清洗再校验，脏值一律回退默认（绝不把引号/空格拼进 shell）
local function ollama_model()
  local v = host.get("ollama_embed_model")
  if type(v) == "string" then
    v = v:gsub("^%s+", ""):gsub("%s+$", "")
    if valid_model_name(v) then return v end
  end
  return OLLAMA_DEFAULT_MODEL
end

-- 是否装了 ollama（5 秒缓存，避免每次重建都探一堆路径）
local OLLAMA_HAVE, OLLAMA_HAVE_T = nil, 0
function ollama_installed()
  local now = host.now_ms()
  if OLLAMA_HAVE ~= nil and (now - OLLAMA_HAVE_T) < 5000 then return OLLAMA_HAVE end
  local ub = host.ubuntu_path()
  local cands = {
    "/root/.ollama/ollama", ub .. "/root/.ollama/ollama",
    "/usr/local/bin/ollama", ub .. "/usr/local/bin/ollama",
    "/usr/bin/ollama", ub .. "/usr/bin/ollama",
  }
  local ok = false
  for _, p in ipairs(cands) do
    if host.exists(p) then ok = true; break end
  end
  OLLAMA_HAVE, OLLAMA_HAVE_T = ok, now
  return ok
end

-- 拉起脚本：先探测 11434，已通就直接退出；然后 exec serve 占住 spawn（便于 host.stop）
local OLLAMA_SERVE_SH = [==[
PORT=__PORT__
if (exec 3<>/dev/tcp/127.0.0.1/"$PORT") 2>/dev/null; then
  echo "Ollama 已在运行（:$PORT），无需重复启动"
  exit 0
fi
BIN=""
for c in "$HOME/.ollama/ollama" /root/.ollama/ollama /usr/local/bin/ollama /usr/bin/ollama; do
  if [ -x "$c" ]; then BIN="$c"; break; fi
done
if [ -z "$BIN" ]; then BIN="$(command -v ollama 2>/dev/null)"; fi
if [ -z "$BIN" ]; then
  echo "⚠️ 未找到 ollama 可执行文件（可放到 /root/.ollama/ollama 或用 PATH 安装）"
  exit 1
fi
echo "启动 Ollama: $BIN serve (:$PORT)"
export OLLAMA_HOST="0.0.0.0:$PORT"
exec "$BIN" serve
]==]

function ollama_start(quiet)
  if not ollama_installed() then
    host.toast("未安装 Ollama：把 ollama 放到 /root/.ollama/ollama 后重试")
    return false
  end
  local s = OLLAMA_SERVE_SH:gsub("__PORT__", tostring(ollama_port()))
  host.spawn(s, "Ollama", "ollama")
  if not quiet then host.nav.go(2) end
  return true
end

function ollama_stop()
  host.stop("ollama")
  host.exec('pkill -f "ollama serve" 2>/dev/null || true')
  host.toast("已停止 Ollama")
end

function ollama_toggle(running)
  -- v3.1.0：启动改走 boot_service（有脚本时会带上 OLLAMA_MODEL 并预热）
  if running then ollama_stop() else ollama_boot_service(false) end
end

-- v3.1.0：模型名以环境变量传给 boot_services.sh（脚本里是 ${OLLAMA_MODEL:-默认}）
local function ollama_env(model)
  return 'OLLAMA_MODEL="' .. (model or ollama_model()) .. '"'
end

-- 有脚本就走脚本（能读 OLLAMA_MODEL + 预热 + 写 ollama.log），没脚本退回 Lua 直接 serve
function ollama_boot_service(quiet)
  if host.exists("/root/boot_services.sh") then
    local cmd = ollama_env() .. " /bin/sh /root/boot_services.sh ollama"
    host.spawn(cmd, "Ollama", "ollama")
    if not quiet then host.nav.go(2) end
    return true
  end
  return ollama_start(quiet)
end

-- 只读 ollama list，核实模型在不在本机（不联网、不拉取）
function ollama_check_model(name)
  if not ollama_installed() then return end
  local cmd = 'BIN=""; '
    .. 'for c in "$HOME/.ollama/ollama" /root/.ollama/ollama /usr/local/bin/ollama /usr/bin/ollama; do '
    .. '[ -x "$c" ] && { BIN="$c"; break; }; done; '
    .. '[ -n "$BIN" ] || BIN="$(command -v ollama 2>/dev/null)"; '
    .. '[ -n "$BIN" ] || exit 3; "$BIN" list 2>/dev/null'
  host.exec(cmd, function(res)
    local out = (res and res.output) or ""
    if out == "" then return end                  -- 拿不到列表就不打扰
    for line in out:gmatch("[^\n]+") do
      local nm = line:match("^%s*(%S+)")
      if nm == name or nm == name .. ":latest" then
        host.notify({ id = 9903, title = "🧠 向量模型已就绪",
          body = name .. " 已在本机，无需再次下载" })
        return
      end
    end
    host.notify({ id = 9903, title = "🧠 向量模型未下载",
      body = "请先执行 ollama pull " .. name .. "，再点「启动 Ollama」" })
  end)
end

-- ---------- Ollama / AstrBot 端口实况（状态灯用，4 秒节流） ----------
local LIVE = { ollama = nil, astrbot = nil, ts = 0, busy = false }
local LIVE_REV = nil          -- 在 stack_card 里挂 state 句柄

local function live_probe_cmd()
  local ps = { tostring(ollama_port()), tostring(ports.get("dashboard")) }
  return "for p in " .. table.concat(ps, " ") .. "; do "
      .. "if (exec 3<>/dev/tcp/127.0.0.1/$p) 2>/dev/null; then echo \"$p up\"; "
      .. "else echo \"$p down\"; fi; done"
end

local function live_probe(force)
  if LIVE.busy then return end
  local now = host.now_ms()
  if not force and (now - LIVE.ts) < 4000 then return end
  LIVE.ts, LIVE.busy = now, true
  host.exec(live_probe_cmd(), function(res)
    LIVE.busy = false
    local out = (res and res.output) or ""
    local map = {}
    for p, st in out:gmatch("(%d+)%s+(%a+)") do map[p] = (st == "up") end
    local changed = false
    local function put(k, v)
      if v ~= nil and LIVE[k] ~= v then LIVE[k] = v; changed = true end
    end
    put("ollama", map[tostring(ollama_port())])
    put("astrbot", map[tostring(ports.get("dashboard"))])
    if changed and LIVE_REV then LIVE_REV.set(LIVE_REV.get() + 1) end
  end)
end

-- v3.1.0：点一下改向量模型（输入 → 校验 → 持久化 → 提示 → 后台核实）
local function edit_ollama_model()
  host.input({
    title = "向量模型",
    hint = "例如 bge-m3 / qwen2.5:7b / nomic-embed-text（改完需 ollama pull）",
    default = ollama_model(),
  }, function(v)
    if v == nil then return end
    v = v:gsub("^%s+", ""):gsub("%s+$", "")
    if v == "" then host.toast("模型名不能为空"); return end
    if not valid_model_name(v) then
      host.toast("模型名只能包含 字母/数字/- _ . : / +")
      return
    end
    if v == ollama_model() then host.toast("模型未变化"); return end

    host.set("ollama_embed_model", v)                        -- 持久化（同时触发页面重建）
    if LIVE_REV then LIVE_REV.set(LIVE_REV.get() + 1) end     -- 双保险：卡片立刻刷新
    host.toast("向量模型已切换至 " .. v .. "，请确保已用 ollama pull 下载该模型")
    host.notify({
      id = 9903,
      title = "🧠 向量模型已切换",
      body = v .. " · 请确保已用 ollama pull 下载该模型",
    })
    ollama_check_model(v)                                    -- 后台核实，缺模型再补一条提示
  end)
end

nav.tabs({
  { title = "主页",  icon = "home_outlined",     page = "home" },
  { title = "WebUI", icon = "language", page = webview() },
  { title = "终端",  icon = "terminal", page = terminal() },
})

-- GitHub 代理: 直连 + 一组镜像, 由 Lua 端测速后择优 (下方 open_gh_dialog)
local GH_PROXIES = {
  { label = "直连 (GitHub 原始)", value = "direct" },
  { label = "Ghfast",     value = "https://ghfast.top" },
  { label = "Gh-Proxy",   value = "https://gh-proxy.com" },
  { label = "GhProxyNet", value = "https://ghproxy.net" },
  { label = "GhProxyCc",  value = "https://ghproxy.cc" },
  { label = "Dpik",       value = "https://gh.dpik.top" },
  { label = "Monlor",     value = "https://gh.monlor.com" },
  { label = "Chjina",     value = "https://gh.chjina.com" },
  { label = "BokiMoe",    value = "https://github.boki.moe" },
  { label = "JasonZeng",  value = "https://gh.jasonzeng.dev" },
  { label = "GeekerTao",  value = "https://gh.geekertao.top" },
  { label = "Nxnow",      value = "https://gh.nxnow.top" },
  { label = "Npee",       value = "https://down.npee.cn" },
}
local function gh_proxy() return host.get("environment_github_proxy") or "direct" end
local function gh_proxy_label(v)
  for _, p in ipairs(GH_PROXIES) do if p.value == v then return p.label end end
  return v
end

-- 镜像测速 (纯 Lua 端): value -> { ms=数字 | err=字符串 | testing=true }
local gh_speed = {}
local GH_TEST_PATH = "/https://raw.githubusercontent.com/astral-sh/uv/main/README.md"
local function gh_test_all()
  local rev = state("gh.speed.rev", 0)
  for _, p in ipairs(GH_PROXIES) do
    if p.value ~= "direct" then
      gh_speed[p.value] = { testing = true }
      local t0 = host.now_ms()
      host.http({
        url = p.value .. GH_TEST_PATH, method = "GET", timeout = 10,
        on_done = function(res)
          if res and res.ok then
            gh_speed[p.value] = { ms = host.now_ms() - t0 }
          else
            gh_speed[p.value] = { err = "HTTP " .. tostring(res and res.status or "?") }
          end
          rev.set(rev.get() + 1)
        end,
        on_error = function() gh_speed[p.value] = { err = "失败" }; rev.set(rev.get() + 1) end,
      })
    end
  end
  rev.set(rev.get() + 1)
end
-- 直连置顶, 其余按延迟升序 (未测/失败沉底)
local function gh_sorted()
  local list = {}
  for _, p in ipairs(GH_PROXIES) do list[#list + 1] = p end
  table.sort(list, function(a, b)
    if a.value == "direct" then return true end
    if b.value == "direct" then return false end
    local sa, sb = gh_speed[a.value], gh_speed[b.value]
    local ma = (sa and sa.ms) or math.huge
    local mb = (sb and sb.ms) or math.huge
    if ma ~= mb then return ma < mb end
    return a.label < b.label
  end)
  return list
end
local function gh_status_widget(p)
  if p.value == "direct" then return text("默认", { size = 12, color = "grey" }) end
  local s = gh_speed[p.value]
  if not s or s.testing then
    return row({ spinner({ size = 14 }), spacer(6), text("测速中", { size = 12, color = "grey" }) }, { cross = "center" })
  elseif s.ms then
    local col = s.ms < 800 and "green" or (s.ms < 2000 and "orange" or "grey")
    return text(s.ms .. " ms", { size = 12, color = col, weight = "bold" })
  else
    return text(s.err or "失败", { size = 12, color = "red" })
  end
end
local function open_gh_dialog()
  gh_test_all()
  host.dialog({
    title = "GitHub 代理测速",
    build = function()
      local rows = {
        row({
          expanded(text("点选一个镜像作为下载代理", { size = 12, color = "grey" })),
          button("重新测速", gh_test_all, { variant = "text", icon = "refresh" }),
        }, { cross = "center" }),
        divider(),
      }
      for _, p in ipairs(gh_sorted()) do
        local sel = gh_proxy() == p.value
        rows[#rows + 1] = tile(p.label, {
          icon = sel and "radio_button_checked" or "radio_button_unchecked",
          trailing = gh_status_widget(p),
          onTap = function()
            host.set("environment_github_proxy", p.value)
            host.close_dialog()
            host.toast("已选择: " .. p.label)
          end,
        })
      end
      return box({ height = 400, child = scroll({ column(rows) }) })
    end,
    actions = { { label = "关闭", variant = "text" } },
  })
end

-- 选中代理时给下载 URL 加前缀 (direct 则直接 github.com)
local function gh_prefix(url)
  local p = gh_proxy()
  if p == "direct" or p == "auto" then return url end
  return p .. "/" .. url
end

-- 环境安装状态: 用通用积木 host.exists 在 Lua 侧判断
local function env_installed(step)
  local ub = host.ubuntu_path()
  if step == "base" then
    return host.exists(ub .. "/usr/bin/git") and host.exists(ub .. "/usr/bin/curl") and host.exists(ub .. "/usr/bin/sudo")
  elseif step == "uv" then
    return host.exists(ub .. "/root/.local/bin/uv")
  elseif step == "napcat" then
    return host.exists(ub .. "/root/launcher.sh") and host.exists(ub .. "/root/napcat")
  elseif step == "astrbot" then
    return host.exists(ub .. "/root/AstrBot/main.py") and host.exists(ub .. "/root/AstrBot/.venv")
  elseif step == "opencode" then
    return agent.installed()
  end
  return false
end

local ENV_STEPS = {
  { id = "base",    title = "基础命令", sub = "sudo / git / curl" },
  { id = "uv",      title = "uv",       sub = "Python 依赖管理工具" },
  { id = "astrbot", title = "AstrBot",  sub = "克隆 AstrBot 并同步依赖" },
  { id = "napcat",  title = "NapCat",   sub = "安装或修复 NapCatQQ" },
  { id = "opencode", title = "OpenCode", sub = "DIY AI coding agent" },
}

-- ============================================================
-- 安装命令: 每个按钮直接下发自己那一步的命令 (无中央分发器)。
-- 共享的辅助函数 (progress/network/各 install_*) 作为 verbatim 常量复用,
-- 每个步骤按钮显式列出自己要执行的调用序列。
-- ============================================================

-- 进容器执行时需要的环境变量前缀
local function env_pre(force)
  return table.concat({
    'export TMPDIR="' .. host.tmp_path() .. '"',
    'export ASTRBOT_DASHBOARD_PORT=' .. tostring(ports.get("dashboard")),
    'export ASTRBOT_ONEBOT_WS_PORT=' .. tostring(ports.get("onebot")),
    'export ASTRBOT_GITHUB_PROXY="' .. gh_proxy() .. '"',
    'export ASTRBOT_FORCE_REINSTALL_STEP="' .. (force or "") .. '"',
    'export L_NOT_INSTALLED=未安装',
    'export L_INSTALLING=安装中',
    'export L_INSTALLED=已安装',
    'export UV_LINK_MODE=copy',
    'export UV_DEFAULT_INDEX="https://pypi.tuna.tsinghua.edu.cn/simple"',
    'export UV_PYTHON_INSTALL_MIRROR="' ..
      gh_prefix("https://github.com/astral-sh/python-build-standalone/releases/download") .. '"',
  }, "\n")
end

-- 共享辅助 (verbatim)
local SH_HELPERS = [==[
progress_echo(){
  echo -e "\033[31m- $@\033[0m"
  echo "$@" > "$TMPDIR/progress_des"
}
prepare_reinstall_step(){
  case "$1" in
    uv)
      progress_echo "uv 重装准备中"
      rm -f "$HOME/.local/bin/uv" "$HOME/.local/bin/uvx"
      ;;
    napcat)
      progress_echo "NapCat 重装准备中"
      if [ -d "$HOME/napcat/config" ]; then
        rm -rf "$HOME/napcat_config_backup"
        cp -r "$HOME/napcat/config" "$HOME/napcat_config_backup"
      fi
      pkill -f 'qq --no-sandbox' 2>/dev/null || true
      pkill -f 'NapCat' 2>/dev/null || true
      pkill -f 'napcat' 2>/dev/null || true
      rm -rf "$HOME/napcat" "$HOME/napcat.sh" "$HOME/launcher.sh"
      ;;
    astrbot)
      progress_echo "AstrBot 重装准备中"
      killall uv 2>/dev/null || true
      rm -rf "$HOME/AstrBot_data_reinstall_backup"
      if [ -d "$HOME/AstrBot/data" ]; then
        cp -r "$HOME/AstrBot/data" "$HOME/AstrBot_data_reinstall_backup"
      fi
      rm -rf "$HOME/AstrBot" "$HOME/AstrBot_tmp"
      ;;
  esac
}
maybe_prepare_reinstall(){
  if [ "$ASTRBOT_FORCE_REINSTALL_STEP" = "$1" ]; then
    prepare_reinstall_step "$1"
  fi
}
]==]

local SH_NET = [==[
network_test() {
  target_proxy=""
  case "$ASTRBOT_GITHUB_PROXY" in
    ""|direct|auto) echo "Github 直连"; return 0 ;;
    *) target_proxy="$ASTRBOT_GITHUB_PROXY"; echo "使用代理: $target_proxy"; return 0 ;;
  esac
}
]==]

local SH_BASE = [==[
install_sudo_curl_git(){
  missing=()
  for cmd in sudo git curl; do
    if ! command -v "$cmd" >/dev/null 2>&1; then missing+=("$cmd"); fi
  done
  if [ ${#missing[@]} -eq 0 ]; then progress_echo "基础命令已安装"; return 0; fi
  progress_echo "基础命令缺失: ${missing[*]}, 开始安装..."
  export DEBIAN_FRONTEND=noninteractive
  apt_opts="-o Acquire::ForceIPv4=true"
  if ! apt-get $apt_opts update; then echo "apt-get update 失败，继续尝试安装..."; fi
  if ! apt-get $apt_opts install -y sudo git curl; then echo "基础命令安装失败"; return 1; fi
  for cmd in sudo git curl; do
    if ! command -v "$cmd" >/dev/null 2>&1; then echo "基础命令安装后仍缺少: $cmd"; return 1; fi
  done
  progress_echo "基础命令安装完成"
}
]==]

local SH_UV = [==[
install_uv(){
  INSTALL_DIR="$HOME/.local/bin"
  ARCHIVE_FILE="uv-aarch64-unknown-linux-gnu.tar.gz"
  mkdir -p "$INSTALL_DIR"
  network_test

  # 探测最新版本: 走 releases/latest 的 302 重定向, 取最终 URL 末段 tag (无需 api.github.com)
  progress_echo "检测 uv 最新版本..."
  LATEST_URL=$(curl -fsSL -o /dev/null -w '%{url_effective}' "${target_proxy:+${target_proxy}/}https://github.com/astral-sh/uv/releases/latest" 2>/dev/null)
  APP_VERSION="${LATEST_URL##*/}"
  case "$APP_VERSION" in
    ""|*latest*) APP_VERSION="0.9.9"; echo "无法获取最新版本, 回退到 $APP_VERSION" ;;
    *) echo "最新 uv 版本: $APP_VERSION" ;;
  esac

  # 已安装同版本 -> 跳过 (重装时按钮已在 prepare_reinstall_step 删除旧二进制)
  if [ -x "$INSTALL_DIR/uv" ]; then
    CUR=$("$INSTALL_DIR/uv" --version 2>/dev/null | awk '{print $2}')
    if [ -n "$CUR" ] && [ "$CUR" = "$APP_VERSION" ]; then
      progress_echo "uv 已是最新 ($CUR)"
      return 0
    fi
    echo "当前 uv ${CUR:-未知}, 将更新到 $APP_VERSION..."
  fi

  progress_echo "uv $L_INSTALLING ($APP_VERSION)..."
  DOWNLOAD_URL="${target_proxy:+${target_proxy}/}https://github.com/astral-sh/uv/releases/download/${APP_VERSION}/${ARCHIVE_FILE}"
  TMP_DIR=$(mktemp -d)
  echo "正在下载 uv $APP_VERSION..."
  if ! curl -fL "$DOWNLOAD_URL" -o "$TMP_DIR/$ARCHIVE_FILE"; then echo "下载失败"; rm -rf "$TMP_DIR"; exit 1; fi
  if ! tar -C "$TMP_DIR" -xf "$TMP_DIR/$ARCHIVE_FILE" --strip-components 1; then echo "解压失败"; rm -rf "$TMP_DIR"; exit 1; fi
  cp "$TMP_DIR/uv" "$TMP_DIR/uvx" "$INSTALL_DIR/" && chmod +x "$INSTALL_DIR/uv" "$INSTALL_DIR/uvx"
  grep -q "$INSTALL_DIR" "$HOME/.bashrc" 2>/dev/null || echo "export PATH=$INSTALL_DIR:\$PATH" >> "$HOME/.bashrc"
  rm -rf "$TMP_DIR"
  progress_echo "uv 安装完成 ($APP_VERSION)"
}
]==]

local SH_NAPCAT = [==[
configure_napcat_token_ttl(){
  if [ -f "$HOME/napcat/napcat.mjs" ]; then
    sed -i -E "s#static MAX_CREDENTIAL_VALID_SECONDS = [0-9]+#static MAX_CREDENTIAL_VALID_SECONDS = 604800#g" "$HOME/napcat/napcat.mjs"
    sed -i -E 's#Rp\.set\(`revoked:\$\{r\}`, !0, [0-9]+\)#Rp.set(`revoked:${r}`, !0, 604800)#g' "$HOME/napcat/napcat.mjs"
  fi
}
install_napcat(){
  if [ ! -f "$HOME/launcher.sh" ]; then
    progress_echo "Napcat $L_NOT_INSTALLED，$L_INSTALLING..."
    apt --fix-broken install -y
    if [ -d "$HOME/napcat/config" ]; then
      echo "备份 NapCat 配置目录..."
      cp -r "$HOME/napcat/config" "$HOME/napcat_config_backup"
    fi
    rm -rf $HOME/napcat
    cd $HOME
    curl -o napcat.sh https://raw.githubusercontent.com/NapNeko/napcat-linux-installer/refs/heads/main/install.sh
    if ! chmod +x napcat.sh; then echo "设置 napcat.sh 执行权限失败"; exit 1; fi
    bash napcat.sh
    pkill -f 'qq --no-sandbox' 2>/dev/null || true
    pkill -f 'NapCat' 2>/dev/null || true
    pkill -f 'napcat' 2>/dev/null || true
    if [ -d "$HOME/napcat_config_backup" ]; then
      echo "恢复 NapCat 配置目录..."
      mkdir -p "$HOME/napcat/config"
      cp -r "$HOME/napcat_config_backup"/* "$HOME/napcat/config/"
      rm -rf "$HOME/napcat_config_backup"
    fi
  if [ ! -f "$HOME/napcat/config/onebot11.json" ]; then
    echo "写入 onebot11.json 默认配置文件"
    cat > "$HOME/napcat/config/onebot11.json" <<EOF
{
  "network": {
    "httpServers": [],
    "httpClients": [],
    "websocketServers": [],
    "websocketClients": [
      {
        "name": "WsClient",
        "enable": true,
        "url": "ws://localhost:${ASTRBOT_ONEBOT_WS_PORT:-6199}/ws",
        "messagePostFormat": "array",
        "reportSelfMessage": false,
        "reconnectInterval": 5000,
        "token": "kasdkfljsadhlskdjhasdlkfshdlafksjdhf",
        "debug": false,
        "heartInterval": 30000
      }
    ]
  },
  "musicSignUrl": "",
  "enableLocalFile2Url": false,
  "parseMultMsg": false
}
EOF
  fi
fi
  configure_napcat_token_ttl
  progress_echo "Napcat $L_INSTALLED"
}
]==]

local SH_ASTRBOT = [==[
install_astrbot(){
  local INSTALL_DIR="$HOME/AstrBot"
  local CLONE_TEMP_DIR="$HOME/AstrBot_tmp"
  local BACKUP_DIR="/sdcard/Download/AstrBotBubble"
  rm -rf "$CLONE_TEMP_DIR"
  killall uv 2>/dev/null
  if [ -d "$INSTALL_DIR" ] && { [ ! -f "$INSTALL_DIR/pyproject.toml" ] || [ ! -f "$INSTALL_DIR/main.py" ]; }; then
    echo "AstrBot 安装目录不完整，准备重新安装..."
    rm -rf "$HOME/AstrBot_data_reinstall_backup"
    if [ -d "$INSTALL_DIR/data" ]; then cp -r "$INSTALL_DIR/data" "$HOME/AstrBot_data_reinstall_backup"; fi
    rm -rf "$INSTALL_DIR"
  fi
  if [ ! -d "$INSTALL_DIR" ]; then
    cd $HOME
    progress_echo "AstrBot $L_NOT_INSTALLED，$L_INSTALLING..."
    echo "正在获取 AstrBot 最新版本..."
    if [ -n "$CUSTOM_GIT_CLONE" ]; then
      echo "使用自定义 Git Clone 命令..."
      if ! eval "$CUSTOM_GIT_CLONE"; then echo "自定义 Git Clone 命令执行失败"; exit 1; fi
      if [ -d "AstrBot" ]; then mv "AstrBot" "$CLONE_TEMP_DIR"; else echo "错误: 未找到 AstrBot 目录"; exit 1; fi
    else
      network_test
      LATEST_TAG=$(git ls-remote --tags --sort='-v:refname' ${target_proxy:+${target_proxy}/}https://github.com/AstrBotDevs/AstrBot.git | awk -F'/' '{print $3}' | sed 's/\^{}//g' | grep -E '^v?[0-9]+(\.[0-9]+){1,2}$' | head -n 1)
      if [ -z "$LATEST_TAG" ]; then echo "警告: 无法获取最新 tag，使用 master 分支"; CLONE_BRANCH="master"; else echo "最新正式版: $LATEST_TAG"; CLONE_BRANCH="$LATEST_TAG"; fi
      echo "正在克隆 AstrBot 仓库，分支/标签: $CLONE_BRANCH..."
      if ! git clone --depth=1 --branch "$CLONE_BRANCH" ${target_proxy:+${target_proxy}/}https://github.com/AstrBotDevs/AstrBot.git "$CLONE_TEMP_DIR"; then
        echo "克隆 AstrBot 仓库失败"; rm -rf "$CLONE_TEMP_DIR"; exit 1
      fi
    fi
    mv "$CLONE_TEMP_DIR" "$INSTALL_DIR"
  else
    progress_echo "AstrBot $L_INSTALLED"
  fi
  progress_echo "AstrBot 初始化中"
  cd "$INSTALL_DIR"
  if [ ! -d "$INSTALL_DIR/data" ]; then
    echo "检测到 data 目录不存在，初始化数据目录..."
    mkdir "$INSTALL_DIR/data"
    if [ -d "$HOME/AstrBot_data_reinstall_backup" ]; then
      echo "恢复重装前 AstrBot 数据..."
      rm -rf "$INSTALL_DIR/data"
      mv "$HOME/AstrBot_data_reinstall_backup" "$INSTALL_DIR/data"
      REINSTALL_PLUGINS_FLAG=1
    else
      LATEST_BACKUP=""
      [ -d "$BACKUP_DIR" ] && LATEST_BACKUP=$(ls -t "$BACKUP_DIR"/AstrBotBubble-backup-*.tar.gz 2>/dev/null | head -n 1)
      if [ -n "$LATEST_BACKUP" ]; then
        echo "找到备份文件: $LATEST_BACKUP"
        if tar -xzf "$LATEST_BACKUP" -C "$INSTALL_DIR"; then
          echo "备份恢复成功"; REINSTALL_PLUGINS_FLAG=1
        else
          echo "备份恢复失败，将使用 AstrBot 默认配置 (首次启动自动生成)"
        fi
      else
        # 不再替换预置 cmd_config.json: AstrBot 首次启动会生成默认配置,
        # NapCat 的 aiocqhttp 适配器改由「创建 NapCat 账号」时自动写入 (见 NC.sync_adapter)。
        echo "无备份，使用 AstrBot 默认配置 (NapCat 适配器在创建账号时自动绑定)"
      fi
    fi
    rm -rf "$INSTALL_DIR/.venv"
  fi
  if [ ! -d "$INSTALL_DIR/.venv" ] || ! $HOME/.local/bin/uv run --no-sync python -c "import aiohttp" >/dev/null 2>&1; then
    echo "同步 AstrBot 依赖..."
    if ! $HOME/.local/bin/uv sync; then echo "依赖同步失败"; exit 1; fi
    REINSTALL_PLUGINS_FLAG=1
  fi
  if [ "$REINSTALL_PLUGINS_FLAG" -eq 1 ]; then
    echo "检测到重装插件依赖标记，开始重装..."
    if [ -d "$INSTALL_DIR/data/plugins" ]; then
      for plugin_dir in "$INSTALL_DIR/data/plugins"/*; do
        if [ -d "$plugin_dir" ] && [ -f "$plugin_dir/requirements.txt" ]; then
          echo "安装插件依赖: $(basename "$plugin_dir")..."
          cd "$INSTALL_DIR"
          $HOME/.local/bin/uv pip install -r "$plugin_dir/requirements.txt" 2>/dev/null || echo "警告: 插件依赖安装失败，将在启动时重试"
        fi
      done
    fi
  fi
  progress_echo "AstrBot 安装完成"
}
]==]

-- 每个按钮下面就是它自己那一步的命令序列:
local function step_base(reinstall)
  host.spawn(env_pre(reinstall and "base" or "") .. "\n" .. SH_HELPERS .. SH_BASE .. [==[
maybe_prepare_reinstall base
install_sudo_curl_git
]==], "基础命令")
  host.nav.go(2)
end

local function step_uv(reinstall)
  host.spawn(env_pre(reinstall and "uv" or "") .. "\n" .. SH_HELPERS .. SH_NET .. SH_BASE .. SH_UV .. [==[
maybe_prepare_reinstall uv
install_sudo_curl_git
install_uv
]==], "uv")
  host.nav.go(2)
end

local function step_napcat(reinstall)
  host.spawn(env_pre(reinstall and "napcat" or "") .. "\n" .. SH_HELPERS .. SH_BASE .. SH_NAPCAT .. [==[
maybe_prepare_reinstall napcat
install_sudo_curl_git
install_napcat
]==], "NapCat")
  host.nav.go(2)
end

local function step_astrbot(reinstall, force_plugins)
  local pre = env_pre(reinstall and "astrbot" or "")
  local flag = force_plugins and "1" or "0"
  host.spawn(pre .. "\nexport REINSTALL_PLUGINS_FLAG=" .. flag .. "\nCUSTOM_GIT_CLONE=\"\"\n"
    .. SH_HELPERS .. SH_NET .. SH_BASE .. SH_UV .. SH_ASTRBOT .. [==[
maybe_prepare_reinstall astrbot
install_sudo_curl_git
install_uv
install_astrbot
]==], "AstrBot")
  host.nav.go(2)
end

local STEP_RUN = {
  base = step_base,
  uv = step_uv,
  napcat = step_napcat,
  astrbot = step_astrbot,
  opencode = function(reinstall) agent.install(reinstall) end,
}

-- ============================================================
-- AstrBot 启停: 纯 Lua, 通过通用原语 host.spawn/host.stop, 运行态读 ctx.running
-- 一操作一终端标签页, 手动模式, 无进度/webview 监听
-- ============================================================
local function astrbot_start_command()
  return table.concat({
    "export TMPDIR='" .. host.tmp_path() .. "'",
    "export ASTRBOT_DASHBOARD_PORT='" .. tostring(ports.get("dashboard")) .. "'",
    "if [ ! -x /root/.local/bin/uv ] || [ ! -d /root/AstrBot ] || [ ! -f /root/AstrBot/pyproject.toml ] || [ ! -f /root/AstrBot/main.py ] || [ ! -d /root/AstrBot/.venv ]; then echo 'AstrBot 环境未安装完整，请到主页环境管理安装。'; exit 1; fi",
    "cd /root/AstrBot",
    "echo 'AstrBot 启动中'",
    "/root/.local/bin/uv run --no-sync main.py",
  }, "; ")
end

function astrbot_toggle(running)
  if running then
    host.stop("astrbot")
  else
    host.spawn(astrbot_start_command(), "AstrBot", "astrbot")
    host.nav.go(2)
  end
end

-- ============================================================
-- NapCat: 实例管理 / 启停 / BOT 绑定 —— 全部纯 Lua
-- 数据存 host.get/set("napcat_instances") (JSON), 配置文件直接读写 rootfs,
-- 启停走 host.spawn/host.stop (key = "napcat:<id>"), 运行态读 ctx.running。
-- Dart 侧不含任何 NapCat 逻辑。
-- ============================================================
local NC = {}
local WEBUI_FIRST, WEBUI_LAST = 6099, 6149
local DISPLAY_FIRST = 22
local ONEBOT_FIRST, ONEBOT_LAST = 6199, 6249
local WS_NAME = "WsClient"
-- 每个 NapCat 实例使用独立随机 token (创建时生成并持久化到实例), NapCat 反向 ws 与
-- AstrBot 适配器共用同一个, 保证一一对应、互不串号。
local function gen_token() return host.random_bytes(16, "hex") end
local function nc_token(ins)
  if not ins.wsToken or ins.wsToken == "" then
    ins.wsToken = gen_token()
    local list = NC.load(); local _, cur = NC.find(list, ins.id)
    if cur and cur ~= ins then cur.wsToken = ins.wsToken; NC.save(list) end
  end
  return ins.wsToken
end

local function nc_root() return host.ubuntu_path() .. "/root" end
local function nc_workdir(id) return nc_root() .. "/napcat_instances/" .. id .. "_napcat" end
local function nc_configdir(id) return nc_workdir(id) .. "/config" end

local function napcat_x_display()
  local d, o, n = ports.get("dashboard"), ports.get("onebot"), ports.get("napcat")
  if d == 6185 and o == 6199 and n == 6099 then return 1 end
  return 10 + d % 80
end

function NC.load()
  local raw = host.get("napcat_instances")
  if type(raw) == "string" and raw ~= "" then
    local ok, v = pcall(json.decode, raw)
    if ok and type(v) == "table" then return v end
  end
  return {}
end

function NC.save(list) host.set("napcat_instances", json.encode(list)) end

function NC.find(list, id)
  for i, v in ipairs(list) do if v.id == id then return i, v end end
end

-- 从 rootfs 里探测该实例已登录的 QQ (通过 onebot11_<qq>.json 文件名)
function NC.detect_qq(id)
  for _, e in ipairs(host.list_dir(nc_configdir(id))) do
    local qq = tostring(e.name):match("^onebot11_(%d+)%.json$")
    if qq then return qq end
  end
  return nil
end

-- ---------- v2.3.0：真实 QQ 号还原（修「登录后仍显示未登录」） ----------
-- 旧逻辑只认实例记录里的 ins.qq，而 ins.qq 从来没被回填过 → 扫码登录后卡片一直
-- 显示"未登录"。这里改成三路只读探测，命中就回写实例记录：
--   ① 实例记录 ins.qq（已识别 / 用户手填）
--   ② onebot11_<uin>.json —— NapCat 登录成功后才生成，最可靠
--   ③ 实例 webui.json 的 autoLoginAccount —— 快速登录账号
--   ④ 日志正则（异步，见 qq_refresh）—— ①②③ 都空时兜底
local QQ_REV = nil          -- state 句柄，在 stack_card 里挂
local QQ_BUSY, QQ_T = false, 0

function NC.is_qq(v)
  if type(v) == "number" then v = tostring(v) end
  return type(v) == "string" and #v >= 5 and #v <= 12 and v:match("^%d+$") ~= nil
end

function NC.hydrate_qq(ins)
  if not ins or not ins.id then return "" end
  if NC.is_qq(ins.qq) then
    ins.qq = tostring(ins.qq)
    return ins.qq
  end

  local okd, dq = pcall(NC.detect_qq, ins.id)   -- 目录不存在时 list_dir 可能抛错
  local q = (okd and type(dq) == "string" and NC.is_qq(dq)) and dq or nil
  if not q then
    local body = host.read_file(nc_configdir(ins.id) .. "/webui.json")
    if body then
      local m = body:match('"autoLoginAccount"%s*:%s*"(%d+)"')
      if m and NC.is_qq(m) then q = m end
    end
  end
  if not q then return "" end

  -- 立刻回写：下次 write_launcher 生成 webui.json 时 autoLoginAccount 就不会再空着
  ins.qq = q
  local list = NC.load()
  local _, cur = NC.find(list, ins.id)
  if cur and cur.qq ~= q then cur.qq = q; NC.save(list) end
  return q
end

-- 日志兜底：NapCat 的登录日志里有 uin / QQ / autoLoginAccount 痕迹。
-- 只读 tail 300KB，多实例时不去碰公共的 /root/napcat.log（避免串号）。
local QQ_SCAN_SH = [==[
__q() {
  id="$1"; single="$2"; d=/root/napcat_instances/${id}_napcat; q=""
  for f in "$d"/config/onebot11_*.json; do
    [ -f "$f" ] || continue
    n=$(basename "$f"); n=${n#onebot11_}; n=${n%.json}
    case "$n" in ''|*[!0-9]*) ;; *) q="$n"; break ;; esac
  done
  if [ -z "$q" ] && [ -f "$d/config/webui.json" ]; then
    q=$(sed -n 's/.*"autoLoginAccount"[[:space:]]*:[[:space:]]*"\([0-9]\{5,12\}\)".*/\1/p' "$d/config/webui.json" 2>/dev/null | head -1)
  fi
  if [ -z "$q" ]; then
    for f in "$d"/logs/*.log; do
      [ -f "$f" ] || continue
      q=$(tail -c 300000 "$f" 2>/dev/null | grep -aoE '(autoLoginAccount[^0-9]{0,16}[0-9]{5,12}|"uin"[[:space:]]*:[[:space:]]*"?[0-9]{5,12}|[uU][iI][nN][^0-9]{0,10}[0-9]{5,12})' | tail -1 | grep -oE '[0-9]{5,12}' | head -1)
      [ -n "$q" ] || q=$(tail -c 300000 "$f" 2>/dev/null | grep -aoE '[Qq][Qq][[:blank:]:=]*[0-9]{5,12}' | tail -1 | grep -oE '[0-9]{5,12}' | head -1)
      [ -n "$q" ] && break
    done
  fi
  if [ -z "$q" ] && [ "$single" = "1" ] && [ -f /root/napcat.log ]; then
    q=$(tail -c 300000 /root/napcat.log 2>/dev/null | grep -aoE '(autoLoginAccount[^0-9]{0,16}[0-9]{5,12}|"uin"[[:space:]]*:[[:space:]]*"?[0-9]{5,12}|[uU][iI][nN][^0-9]{0,10}[0-9]{5,12})' | tail -1 | grep -oE '[0-9]{5,12}' | head -1)
    [ -n "$q" ] || q=$(tail -c 300000 /root/napcat.log 2>/dev/null | grep -aoE '[Qq][Qq][[:blank:]:=]*[0-9]{5,12}' | tail -1 | grep -oE '[0-9]{5,12}' | head -1)
  fi
  echo "$id|$q"
}
]==]

local function qq_scan_cmd(ids)
  local single = (#ids == 1) and "1" or "0"
  local calls = {}
  for _, id in ipairs(ids) do
    calls[#calls + 1] = '__q "' .. tostring(id) .. '" "' .. single .. '"'
  end
  return QQ_SCAN_SH .. table.concat(calls, "; ")
end

-- 只给"还没有 QQ 号"的实例跑一次日志扫描；8 秒节流，防止频繁重建时刷屏。
local function qq_refresh(force)
  if QQ_BUSY then return end
  local now = host.now_ms()
  if not force and (now - QQ_T) < 8000 then return end
  QQ_T = now

  local ids = {}
  for _, ins in ipairs(NC.load()) do
    if not NC.is_qq(ins.qq) then ids[#ids + 1] = ins.id end
  end
  if #ids == 0 then return end

  QQ_BUSY = true
  host.exec(qq_scan_cmd(ids), function(res)
    QQ_BUSY = false
    local out = (res and res.output) or ""
    local list = NC.load()
    local changed = false
    for id, q in out:gmatch("([%w_]+)|(%d+)") do
      local _, ins = NC.find(list, id)
      if ins and NC.is_qq(q) and ins.qq ~= q then
        ins.qq = q
        changed = true
      end
    end
    if changed then
      NC.save(list)
      if QQ_REV then QQ_REV.set(QQ_REV.get() + 1) end
    end
  end)
end

-- ---------- onebot 配置 ----------
local function ws_url(port) return "ws://localhost:" .. port .. "/ws" end
local function ws_port_of(url) return tonumber((tostring(url or "")):match("^wss?://[^/:]+:(%d+)")) end

local function build_onebot_config(port, token)
  return {
    network = {
      httpServers = {}, httpClients = {}, websocketServers = {},
      websocketClients = {
        { name = WS_NAME, enable = true, url = ws_url(port), messagePostFormat = "array",
          reportSelfMessage = false, reconnectInterval = 5000, token = token,
          debug = false, heartInterval = 30000 },
      },
    },
    musicSignUrl = "", enableLocalFile2Url = false, parseMultMsg = false,
  }
end

-- 确保该实例的 onebot 反向 ws 客户端配置正确 (模板 + 已登录账号文件都写)。
-- 每个实例固定一个 ws client (WS_NAME), 指向本实例 oneBotPort, 用本实例随机 token。
function NC.ensure_ws(ins)
  local id = ins.id
  local port = ins.oneBotPort or ONEBOT_FIRST
  local token = nc_token(ins)
  host.mkdirs(nc_configdir(id))
  local client = {
    name = WS_NAME, enable = true, url = ws_url(port), messagePostFormat = "array",
    reportSelfMessage = false, reconnectInterval = 5000, token = token,
    debug = false, heartInterval = 30000,
  }
  local files = { nc_configdir(id) .. "/onebot11.json" }
  local qq = NC.detect_qq(id)
  if qq then files[#files + 1] = nc_configdir(id) .. "/onebot11_" .. qq .. ".json" end
  for _, p in ipairs(files) do
    local cfg
    local t = host.read_file(p)
    if t then local ok, v = pcall(json.decode, t); if ok and type(v) == "table" then cfg = v end end
    if not cfg then cfg = build_onebot_config(port, token) end
    cfg.network = type(cfg.network) == "table" and cfg.network or {}
    cfg.network.httpServers      = cfg.network.httpServers or {}
    cfg.network.httpClients      = cfg.network.httpClients or {}
    cfg.network.websocketServers = cfg.network.websocketServers or {}
    cfg.network.websocketClients = { client }
    host.write_file(p, json.encode(cfg))
  end
end

-- 初始化模板 (不存在才写); 已存在则交给 ensure_ws 修正
function NC.ensure_onebot(ins)
  NC.ensure_ws(ins)
end

-- ---------- AstrBot cmd_config (aiocqhttp 适配器) ----------
-- 绑定模型 (多实例, 全自动): 每个 NapCat 账号在 AstrBot 里独占一条 aiocqhttp 适配器,
--   ws_reverse_port = 本账号 oneBotPort, ws_reverse_token = 固定 token。
--   创建账号 → 自动写入; 退出/删除账号 → 自动移除。不再替换预置 cmd_config.json。
local function astrbot_config_path()
  return host.ubuntu_path() .. "/root/AstrBot/data/cmd_config.json"
end

local function read_astrbot_config()
  local t = host.read_file(astrbot_config_path())
  if not t then return nil end
  local ok, v = pcall(json.decode, t)
  if ok and type(v) == "table" then return v end
  return nil
end

local function write_astrbot_config(cfg)
  host.write_file(astrbot_config_path(), json.encode(cfg))
end

function NC.list_adapters()
  local cfg = read_astrbot_config()
  local res = {}
  if not cfg or type(cfg.platform) ~= "table" then return res end
  for _, item in ipairs(cfg.platform) do
    if type(item) == "table" and item.type == "aiocqhttp" then
      res[#res + 1] = {
        id = tostring(item.id or ""), enabled = item.enable ~= false,
        port = tonumber(item.ws_reverse_port) or -1,
        token = tostring(item.ws_reverse_token or ""),
      }
    end
  end
  return res
end

local function unique_adapter_id(base, cfg)
  base = (base and base:gsub("^%s+", ""):gsub("%s+$", "") ~= "") and base or "NapCat"
  local used = {}
  if type(cfg.platform) == "table" then
    for _, it in ipairs(cfg.platform) do if type(it) == "table" and it.id then used[tostring(it.id)] = true end end
  end
  if not used[base] then return base end
  local i = 2
  while used[base .. i] do i = i + 1 end
  return base .. i
end

-- ---------- 绑定 (全自动: 创建账号即写入适配器) ----------
-- 在 AstrBot 配置里为该实例建/改适配器 (端口/token 对齐本实例)。
-- 返回: "created" 新建 | "ok" 已同步 | "nocfg" AstrBot 尚未安装/无配置
function NC.sync_adapter(ins)
  local cfg = read_astrbot_config()
  if not cfg then return "nocfg" end
  if type(cfg.platform) ~= "table" then cfg.platform = {} end
  local port = ins.oneBotPort or ONEBOT_FIRST
  local token = nc_token(ins)
  local target
  if ins.boundAdapterId and ins.boundAdapterId ~= "" then
    for _, item in ipairs(cfg.platform) do
      if type(item) == "table" and item.id == ins.boundAdapterId then target = item; break end
    end
  end
  local created = false
  if not target then
    local aid = unique_adapter_id(ins.name, cfg)
    target = { id = aid, type = "aiocqhttp" }
    cfg.platform[#cfg.platform + 1] = target
    ins.boundAdapterId = aid
    created = true
  end
  target.type = "aiocqhttp"
  target.enable = true
  target.ws_reverse_host = "0.0.0.0"
  target.ws_reverse_port = port
  target.ws_reverse_token = token
  write_astrbot_config(cfg)
  -- 回写 boundAdapterId 到持久列表
  local list = NC.load(); local _, cur = NC.find(list, ins.id)
  if cur then
    cur.boundAdapterId = ins.boundAdapterId
    cur.boundWebSocketName = WS_NAME
    NC.save(list)
  end
  return created and "created" or "ok"
end

-- 从 AstrBot 配置移除该实例的适配器 (退出登录 / 删除账号时)
function NC.unbind_adapter(ins)
  if not ins.boundAdapterId or ins.boundAdapterId == "" then return end
  local cfg = read_astrbot_config()
  if not cfg or type(cfg.platform) ~= "table" then return end
  local changed = false
  for i = #cfg.platform, 1, -1 do
    local item = cfg.platform[i]
    if type(item) == "table" and item.id == ins.boundAdapterId then
      table.remove(cfg.platform, i); changed = true
    end
  end
  if changed then write_astrbot_config(cfg) end
end

-- 绑定状态: "configured" 端口/token 一致 | "mismatch" 存在但不一致 |
--           "unbound" 无适配器 | "nocfg" AstrBot 未安装
function NC.binding_state(ins)
  if not read_astrbot_config() then return "nocfg" end
  local port = ins.oneBotPort or ONEBOT_FIRST
  local token = ins.wsToken or ""
  for _, a in ipairs(NC.list_adapters()) do
    if a.id == ins.boundAdapterId and ins.boundAdapterId ~= "" then
      if a.enabled and a.port == port and token ~= "" and a.token == token then return "configured" end
      return "mismatch"
    end
  end
  return "unbound"
end

-- ---------- launcher 脚本 ----------
local LAUNCHER_TMPL = [==[
#!/bin/bash
set -u

BASE_HOME="/root"
INSTANCE_ID='__ID__'
INSTANCE_HOME="$BASE_HOME/napcat_instances/${INSTANCE_ID}_home"
INSTANCE_WORKDIR="$BASE_HOME/napcat_instances/${INSTANCE_ID}_napcat"
INSTANCE_DISPLAY="__DISPLAY__"
WEBUI_PORT="__PORT__"

mkdir -p "$INSTANCE_HOME" "$INSTANCE_WORKDIR/config" "$INSTANCE_WORKDIR/logs" "$INSTANCE_WORKDIR/cache"
mkdir -p "$INSTANCE_HOME/.config" "$INSTANCE_HOME/.cache" "$INSTANCE_HOME/.local/share"

if [ -d "$BASE_HOME/napcat/config" ]; then
  cp -n "$BASE_HOME/napcat/config/"*.json "$INSTANCE_WORKDIR/config/" 2>/dev/null || true
fi

cat > "$INSTANCE_WORKDIR/config/webui.json" <<'WEBUIEOF'
__WEBUI_JSON__
WEBUIEOF

echo "[napcat-instance] id=$INSTANCE_ID"
echo "[napcat-instance] DISPLAY=:$INSTANCE_DISPLAY"
echo "[napcat-instance] NAPCAT_WORKDIR=$INSTANCE_WORKDIR"
echo "[napcat-instance] WEBUI_PORT=$WEBUI_PORT"

if [ -f "$INSTANCE_WORKDIR/xvfb.pid" ]; then
  kill "$(cat "$INSTANCE_WORKDIR/xvfb.pid")" 2>/dev/null || true
fi
pkill -f "Xvfb :$INSTANCE_DISPLAY" 2>/dev/null || true
rm -f "/tmp/.X${INSTANCE_DISPLAY}-lock" "/tmp/.X11-unix/X${INSTANCE_DISPLAY}" 2>/dev/null || true
mkdir -p /tmp/.X11-unix
chmod 1777 /tmp/.X11-unix 2>/dev/null || true

Xvfb ":$INSTANCE_DISPLAY" -screen 0 800x600x16 +extension GLX +render > "$INSTANCE_WORKDIR/xvfb.log" 2>&1 &
echo "$!" > "$INSTANCE_WORKDIR/xvfb.pid"
for i in $(seq 1 50); do
  if [ -S "/tmp/.X11-unix/X${INSTANCE_DISPLAY}" ]; then
    break
  fi
  if ! kill -0 "$(cat "$INSTANCE_WORKDIR/xvfb.pid")" 2>/dev/null; then
    echo "[napcat-instance] Xvfb 启动失败"
    cat "$INSTANCE_WORKDIR/xvfb.log" 2>/dev/null || true
    exit 1
  fi
  sleep 0.1
done
if [ ! -S "/tmp/.X11-unix/X${INSTANCE_DISPLAY}" ]; then
  echo "[napcat-instance] Xvfb 未就绪，无法启动 QQ"
  cat "$INSTANCE_WORKDIR/xvfb.log" 2>/dev/null || true
  exit 1
fi
export DISPLAY=":$INSTANCE_DISPLAY"
export NAPCAT_WORKDIR="$INSTANCE_WORKDIR"
export HOME="$INSTANCE_HOME"
export XDG_CONFIG_HOME="$INSTANCE_HOME/.config"
export XDG_CACHE_HOME="$INSTANCE_HOME/.cache"
export XDG_DATA_HOME="$INSTANCE_HOME/.local/share"

mkdir -p "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME" "$XDG_DATA_HOME"

cd "$BASE_HOME"
trap "" SIGPIPE
LD_PRELOAD=./libnapcat_launcher.so qq --no-sandbox
]==]

function NC.write_launcher(ins)
  local webui = json.encode({
    host = "0.0.0.0", port = ins.webUiPort, prefix = "", token = "",
    loginRate = 3, autoLoginAccount = ins.qq or "",
  })
  local s = LAUNCHER_TMPL
  s = s:gsub("__ID__", (ins.id:gsub("%%", "%%%%")))
  s = s:gsub("__DISPLAY__", tostring(ins.display))
  s = s:gsub("__PORT__", tostring(ins.webUiPort))
  s = s:gsub("__WEBUI_JSON__", (webui:gsub("%%", "%%%%")))
  host.write_file(nc_root() .. "/launcher_" .. ins.id .. ".sh", s)
end

-- ---------- 生命周期 ----------
function NC.add(name)
  local list = NC.load()
  local usedDisp = { [napcat_x_display()] = true }
  for _, v in ipairs(list) do usedDisp[v.display] = true end
  local display
  for d = DISPLAY_FIRST, 99 do if not usedDisp[d] then display = d; break end end
  if not display then host.toast("没有可用 DISPLAY"); return end

  local wexcl = { ports.get("dashboard"), ports.get("onebot") }
  for _, v in ipairs(list) do wexcl[#wexcl + 1] = v.webUiPort end
  host.free_port(WEBUI_FIRST, WEBUI_LAST, wexcl, function(webPort)
    if not webPort then host.toast("没有可用 WebUI 端口"); return end
    local oexcl = { ports.get("dashboard") }
    for _, v in ipairs(list) do if v.oneBotPort then oexcl[#oexcl + 1] = v.oneBotPort end end
    host.free_port(ONEBOT_FIRST, ONEBOT_LAST, oexcl, function(obPort)
      if not obPort then host.toast("没有可用 OneBot 端口"); return end
      local idx = #list + 1
      local nm = (name and name:gsub("^%s+", ""):gsub("%s+$", "") ~= "") and name or ("账号" .. idx)
      local ins = {
        id = "qq" .. idx .. "_" .. tostring(os.time()) .. tostring(math.random(1000, 9999)),
        name = nm, qq = "", webUiPort = webPort, display = display,
        oneBotPort = obPort, token = "", wsToken = gen_token(),
        boundWebSocketName = WS_NAME, boundAdapterId = "",
      }
      list[#list + 1] = ins
      NC.save(list)
      NC.ensure_onebot(ins)
      -- 创建即绑定: 在 AstrBot 里写入对应 aiocqhttp 适配器 (AstrBot 未装则跳过, 启动时补绑)
      local r = NC.sync_adapter(ins)
      if r == "created" or r == "ok" then host.toast("已创建 " .. nm .. " 并绑定 AstrBot 适配器")
      else host.toast("已创建 " .. nm .. " (AstrBot 未安装, 启动后自动绑定)") end
    end)
  end)
end

function NC.edit(id, name, webPort)
  local list = NC.load(); local _, ins = NC.find(list, id)
  if not ins then return end
  if name and name ~= "" then ins.name = name end
  if webPort and webPort ~= ins.webUiPort then
    if webPort < WEBUI_FIRST or webPort > WEBUI_LAST then
      host.toast("WebUI 端口需在 " .. WEBUI_FIRST .. "-" .. WEBUI_LAST); return
    end
    for _, v in ipairs(list) do
      if v.id ~= id and v.webUiPort == webPort then host.toast("端口已被占用"); return end
    end
    ins.webUiPort = webPort
  end
  NC.hydrate_qq(ins)     -- v2.3.0：重写 launcher 前把真实 QQ 回填进 autoLoginAccount
  NC.save(list)
  NC.write_launcher(ins)
end

function NC.start(id)
  local list = NC.load(); local _, ins = NC.find(list, id)
  if not ins then return end
  NC.hydrate_qq(ins)     -- v2.3.0：先回填真实 QQ，write_launcher 才不会把 autoLoginAccount 写空
  NC.ensure_ws(ins)
  NC.sync_adapter(ins)   -- 补绑: 若创建时 AstrBot 尚未安装, 此处补上适配器
  NC.write_launcher(ins)
  local cmd = "echo [napcat] run launcher_" .. id .. ".sh; " ..
    "chmod +x /root/launcher_" .. id .. ".sh; bash /root/launcher_" .. id .. ".sh"
  host.spawn(cmd, ins.name or id, "napcat:" .. id)
  host.nav.go(2)
end

local function nc_cleanup_cmd(id, display)
  local c = {
    'if [ -f /root/napcat_instances/' .. id .. '_napcat/qq.pid ]; then kill "$(cat /root/napcat_instances/' .. id .. '_napcat/qq.pid)" 2>/dev/null || true; fi',
    'if [ -f /root/napcat_instances/' .. id .. '_napcat/xvfb.pid ]; then kill "$(cat /root/napcat_instances/' .. id .. '_napcat/xvfb.pid)" 2>/dev/null || true; fi',
    'pkill -f "launcher_' .. id .. '.sh" || true',
    'pkill -f "napcat_instances/' .. id .. '_napcat" || true',
    'pkill -f "napcat_instances/' .. id .. '_home" || true',
  }
  if display and display > 0 then c[#c + 1] = 'pkill -f "Xvfb :' .. display .. '" || true' end
  c[#c + 1] = 'rm -f /root/napcat_instances/' .. id .. '_napcat/qq.pid'
  c[#c + 1] = 'rm -f /root/napcat_instances/' .. id .. '_napcat/xvfb.pid'
  return table.concat(c, "; ")
end

function NC.stop(id)
  host.stop("napcat:" .. id)
  local list = NC.load(); local _, ins = NC.find(list, id)
  host.exec(nc_cleanup_cmd(id, ins and ins.display or -1))
end

-- ============================================================
-- 【本文件新增】全栈一键启停 + 状态汇总
--
-- 说明：不引入任何新的原生能力，全部复用现有原语：
--   host.spawn(命令, 标签名, key)  —— 容器内跑长命令，流式输出到终端 tab
--   host.stop(key)                  —— 停掉某个 spawn
--   ctx.running[key]                —— 读取运行态（宿主维护，无需轮询）
--   host.delay(ms, cb)              —— 错峰启动，避免同时开一堆终端标签
--
-- 启动顺序刻意设为「先 AstrBot，后 NapCat」：
--   AstrBot 是对接 ws 的被连端（监听 dashboard 端口），NapCat 作为 ws 客户端去连它。
--   NapCat 自带 reconnectInterval，即使先起也会自己重连，但先起 AstrBot 更省事。
-- ============================================================

-- 汇总当前全栈状态，供状态灯使用
-- v2.3.0: QQ 号不再只看 ins.qq，先走 NC.hydrate_qq 从 rootfs 还原真实 UIN；
--         Ollama 带上端口实况与「是否安装」两个维度。
function stack_state(ctx)
  local running = (ctx and ctx.running) or {}
  local list = NC.load()
  local nc_up, nc_qq, uins = 0, 0, {}
  for _, ins in ipairs(list) do
    if running["napcat:" .. ins.id] then nc_up = nc_up + 1 end
    local uin = NC.hydrate_qq(ins)
    if uin ~= "" then
      nc_qq = nc_qq + 1
      uins[#uins + 1] = uin
    end
  end

  -- Ollama：探测结果优先（可能由 boot_services.sh 拉起，不在 ctx.running 里）
  local oll
  if LIVE.ollama ~= nil then oll = LIVE.ollama
  elseif running["ollama"] then oll = true
  else oll = false end

  -- AstrBot：同样给出「记账值」和「端口实况」两份，灯用实况，启停逻辑用记账值
  local ab = running["astrbot"] and true or false
  local ab_live
  if LIVE.astrbot ~= nil then ab_live = LIVE.astrbot else ab_live = ab end

  return {
    astrbot       = ab,
    astrbot_live  = ab_live,
    napcat_up     = nc_up,
    napcat_total  = #list,
    qq            = nc_qq,
    qq_list       = uins,
    ollama        = oll,
    ollama_ready  = ollama_installed(),
    ollama_port   = ollama_port(),
    ollama_model  = ollama_model(),
  }
end

-- 一键启动全栈：Ollama → AstrBot → 各 NapCat 实例（错峰）
function boot_all(ctx)
  -- v2.3.0：有 boot_services.sh 就走它 —— 它内部顺序是 Ollama → NapCat → AstrBot，
  --         先备份/恢复 webui.json 防重置，并顺带拉起 clean_daemon.sh --loop（带 pid 锁）
  if host.exists("/root/boot_services.sh") then
    -- v3.1.0：把用户在界面上配置的模型名传进脚本（脚本用 ${OLLAMA_MODEL:-默认} 接收）
    host.spawn(ollama_env() .. " /bin/sh /root/boot_services.sh start", "全栈启动", "stack_boot")
    host.toast("已调用 boot_services.sh start（Ollama → NapCat → AstrBot，模型 " .. ollama_model() .. "）")
    host.delay(4000, function() live_probe(true) end)
    return
  end

  local st = stack_state(ctx)
  local started = 0
  local delay = 0

  -- v2.3.0：Ollama 排在最前 —— AstrBot 一启动就可能调 embedding，本地模型要先就绪
  if st.ollama_ready and not st.ollama then
    if ollama_boot_service(true) then   -- quiet：不抢页面，交给后面的 AstrBot 跳终端
      started = started + 1
      delay = 1500                      -- 错峰：给 ollama serve 一点启动时间
    end
  end

  if not st.astrbot then
    local go = function() astrbot_toggle(false) end   -- 复用既有实现：spawn + 切到终端页看日志
    if delay > 0 then host.delay(delay, go) else go() end
    started = started + 1
    delay = delay + 1200
  end

  local list = NC.load()
  for _, ins in ipairs(list) do
    if not (ctx and ctx.running and ctx.running["napcat:" .. ins.id]) then
      local id = ins.id
      if delay == 0 then
        NC.start(id)
      else
        host.delay(delay, function() NC.start(id) end)
        delay = delay + 1500
      end
      started = started + 1
    end
  end

  if started == 0 then
    host.toast("全栈已在运行，无需重复启动")
  else
    host.toast("已启动 " .. started .. " 项，可在终端页看日志")
  end
  host.delay(3000, function() live_probe(true) end)     -- 让 Ollama / AstrBot 灯跟上
  host.delay(12000, function() qq_refresh(true) end)    -- 自动登录后补捞真实 QQ 号
end

-- ---------- 自动看护（后台定时器） ----------
-- 宿主内建前台保活服务：退到后台后 host.interval 仍会继续运行，
-- 所以这里可以在后台一直盯着，掉线自动拉起。
-- 通知 id 固定，覆盖更新不堆叠；避开 1001（前台保活服务占用）。
local WATCH = {
  timer     = nil,
  ms        = 60000,   -- 巡检间隔：60 秒
  fails     = {},      -- key -> 连续失败次数
  last_sig  = nil,
  notify_id = 9901,
  alarm_id  = 9902,
  max_tries = 3,       -- 连续失败 3 次后降频
  cooldown  = 10,      -- 之后每 10 个周期（10 分钟）再试一次
}

function watch_enabled()
  local v = host.get("stack_watch")
  if v == nil or v == "" then return true end   -- 默认开启
  return v == true or v == "true"
end

function watch_set(on)
  host.set("stack_watch", on and "true" or "false")
  if on then stack_watch_start() else stack_watch_stop() end
  host.toast(on and "自动看护已开启" or "自动看护已关闭")
end

-- 探测命令：用 bash 的 /dev/tcp，不依赖 nc/curl
-- v2.3.0：11434（Ollama）与 dashboard（AstrBot）一起探，一轮拿到全栈实况
local function watch_probe_cmd()
  local ps = { tostring(ports.get("dashboard")), tostring(ollama_port()) }
  for _, ins in ipairs(NC.load()) do ps[#ps + 1] = tostring(ins.webUiPort) end
  return "for p in " .. table.concat(ps, " ") .. "; do "
      .. "if (exec 3<>/dev/tcp/127.0.0.1/$p) 2>/dev/null; then echo \"$p up\"; "
      .. "else echo \"$p down\"; fi; done"
end

-- 带退避的拉起
local function watch_rescue(key, fn)
  local n = (WATCH.fails[key] or 0) + 1
  WATCH.fails[key] = n
  if n > WATCH.max_tries then
    -- 降频通知只发一次（n == max_tries + 1 那一轮）
    if n == WATCH.max_tries + 1 then
      host.notify({ id = WATCH.alarm_id, title = "🐟 自动拉起",
        body = key .. " 连续失败 " .. WATCH.max_tries .. " 次，已降频为每 10 分钟一次" })
    end
    if n % WATCH.cooldown ~= 0 then return end   -- 降频：每 10 个周期试一次
  else
    host.notify({ id = WATCH.alarm_id, title = "🐟 自动拉起",
      body = key .. " 掉线，第 " .. n .. " 次尝试拉起" })
  end
  fn()
end

function stack_watch_tick()
  if not watch_enabled() then return end
  host.exec(watch_probe_cmd(), function(res)
    local out = (res and res.output) or ""
    local up = {}
    for p, st in out:gmatch("(%d+)%s+(%a+)") do up[p] = (st == "up") end
    if next(up) == nil then return end          -- 探测没结果，这轮不动手

    local dash = tostring(ports.get("dashboard"))
    local op = tostring(ollama_port())
    local list = NC.load()

    -- Ollama（本地向量模型）：没安装就跳过，避免每分钟空拉一次
    if up[op] == false and ollama_installed() then
      -- v3.1.0：走脚本时把当前模型名传过去（预热的就是用户选的那个模型）
      watch_rescue("Ollama", function() ollama_boot_service(true) end)
    elseif up[op] then
      WATCH.fails["Ollama"] = 0
    end

    -- AstrBot
    if up[dash] == false then
      watch_rescue("AstrBot", function() astrbot_toggle(false) end)
    else
      WATCH.fails["AstrBot"] = 0
    end

    -- NapCat 各实例
    local n_up, qq = 0, 0
    for _, ins in ipairs(list) do
      local p = tostring(ins.webUiPort)
      if up[p] then
        n_up = n_up + 1
        WATCH.fails["napcat:" .. ins.id] = 0
      elseif up[p] == false then
        local id = ins.id
        watch_rescue("napcat:" .. id, function() NC.start(id) end)
      end
      if NC.hydrate_qq(ins) ~= "" then qq = qq + 1 end
    end

    -- 状态栏常驻通知：只有变化才更新
    local sig = (up[dash] and "1" or "0") .. "/" .. (up[op] and "1" or "0")
      .. "/" .. n_up .. "/" .. #list .. "/" .. qq
    if sig ~= WATCH.last_sig then
      WATCH.last_sig = sig
      host.notify({
        id = WATCH.notify_id, ongoing = true,
        title = "🐟 全栈状态",
        body = string.format("AstrBot %s · Ollama %s · NapCat %d/%d · QQ %d",
          up[dash] and "运行" or "已停", up[op] and "运行" or "已停", n_up, #list, qq),
      })
    end

    -- 登录后 NapCat 只在日志里留痕：每轮顺手补捞一次，卡片最多 60s 内跟上
    qq_refresh(true)
  end)
end

function stack_watch_start()
  if WATCH.timer then return end
  WATCH.timer = host.interval(WATCH.ms, stack_watch_tick)
end

function stack_watch_stop()
  if WATCH.timer then host.clear_interval(WATCH.timer); WATCH.timer = nil end
end

-- 全部停止：Ollama + AstrBot + 所有 NapCat 实例
function stop_all(ctx)
  local running = (ctx and ctx.running) or {}
  local n = 0
  if running["ollama"] or LIVE.ollama == true then ollama_stop(); n = n + 1 end
  if running["astrbot"] then astrbot_toggle(true); n = n + 1 end
  for _, ins in ipairs(NC.load()) do
    if running["napcat:" .. ins.id] then NC.stop(ins.id); n = n + 1 end
  end
  host.delay(1500, function() live_probe(true) end)   -- 让灯跟着灭
  host.toast(n > 0 and ("已停止 " .. n .. " 项") or "当前没有在运行的项")
end

function NC.logout(id)
  NC.stop(id)
  host.exec('rm -rf /root/napcat_instances/' .. id .. '_napcat; ' ..
    'rm -rf /root/napcat_instances/' .. id .. '_home; rm -f /root/launcher_' .. id .. '.sh')
  local list = NC.load(); local _, ins = NC.find(list, id)
  if ins then
    NC.unbind_adapter(ins)   -- 从 AstrBot 移除该账号的适配器
    ins.qq = ""; ins.token = ""; ins.boundWebSocketName = ""; ins.boundAdapterId = ""
    NC.save(list)
  end
end

function NC.delete(id)
  NC.logout(id)
  local list = NC.load(); local i = NC.find(list, id)
  if i then table.remove(list, i); NC.save(list) end
end

-- NapCat 会把 WebUI 登录 token 写入实例配置文件。每次需要打开/复制
-- WebUI 时直接读取文件，避免依赖容易漏日志或串实例的终端输出监听。
function NC.read_webui_token(ins)
  if not ins or not ins.id then return "" end
  local body = host.read_file(nc_configdir(ins.id) .. "/webui.json")
  if not body or body == "" then return tostring(ins.token or "") end

  local ok, cfg = pcall(json.decode, body)
  if not ok or type(cfg) ~= "table" then return tostring(ins.token or "") end
  local token = tostring(cfg.token or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if token == "" then return tostring(ins.token or "") end

  if ins.token ~= token then
    ins.token = token
    local list = NC.load()
    local _, saved = NC.find(list, ins.id)
    if saved and saved.token ~= token then
      saved.token = token
      NC.save(list)
    end
  end
  return token
end

function NC.webui_url(ins)
  local token = NC.read_webui_token(ins)
  local url = "http://127.0.0.1:" .. ins.webUiPort .. "/webui"
  if token ~= "" then url = url .. "?token=" .. token end
  return url
end

-- ============================================================
-- 主页 UI
-- ============================================================

-- 【v2.3.0】新的全栈状态卡（唯一一张卡）在 napcat_tile / accounts_expansion 之后定义：
--   它要在账号列表里复用 napcat_tile，所以不能再放在这里。
--   本位置保留说明，避免以后翻代码时以为卡片丢了。

-- 【v2.3.0 已删除】原 AstrBot 独立卡（v2.2.x 中名为 quick_start_card / astrbot_card）
--   端口编辑并入 stack_card 的「账号与端口」折叠区；
--   启停与 WebUI 入口并入 stack_card 的按钮行。

local function env_card()
  local children = {
    tile("GitHub 代理", {
      icon = "cloud_sync_outlined",
      subtitle = "当前: " .. gh_proxy_label(gh_proxy()) .. " · 点击测速并选择镜像",
      trailing = icon("chevron_right"),
      onTap = open_gh_dialog,
    }),
  }
  for _, s in ipairs(ENV_STEPS) do
    local done = env_installed(s.id)
    children[#children + 1] = tile(s.title, {
      icon = done and "check_circle" or "error_outline",
      iconColor = done and "green" or "orange",
      subtitle = s.sub,
      trailing = button(done and "重装" or "安装", function()
        STEP_RUN[s.id](done)
      end, { variant = "tonal" }),
    })
  end
  return expansion("环境管理", children, { icon = "build_outlined" })
end

local function add_napcat()
  host.input({ title = "新建 NapCat 账号", hint = "账号备注名 (留空自动命名)" }, function(name)
    NC.add(name or "")
  end)
end

-- BOT 绑定对话框: 现在绑定是全自动的 (创建账号即写入适配器)。
-- 这里只展示绑定状态, 并提供「重新对齐」以应对刚扫码登录 / 手动改过配置的情况。
local function bind_bot_dialog(ins)
  local id = ins.id
  host.dialog({
    title = "BOT 绑定",
    build = function()
      local list = NC.load(); local _, cur = NC.find(list, id)
      cur = cur or ins
      local st = NC.binding_state(cur)
      local map = {
        configured = { "已绑定 · 端口/令牌一致", "green" },
        mismatch   = { "适配器与账号端口/令牌不一致, 点下方重新对齐", "orange" },
        unbound    = { "AstrBot 中尚无该账号适配器, 点下方创建", "grey" },
        nocfg      = { "AstrBot 尚未安装 (启动后自动绑定)", "red" },
      }
      local info = map[st] or map.unbound
      return column({
        chip(info[1], { color = info[2] }),
        text(cur.name or id, { weight = "bold" }),
        text("反向 WS 端口 " .. tostring(cur.oneBotPort or "?"), { size = 12, color = "grey" }),
        text("适配器 " .. ((cur.boundAdapterId ~= "" and cur.boundAdapterId) or "(未创建)")
          .. " · token " .. ((cur.wsToken and cur.wsToken ~= "") and "随机(已设置)" or "空"),
          { size = 12, color = "grey" }),
        text("创建账号时已自动在 AstrBot 写入 aiocqhttp 适配器; 无需手动配置 pre-config。",
          { size = 12, color = "grey" }),
      }, { cross = "stretch", gap = 8 })
    end,
    actions = {
      { label = "关闭", variant = "text" },
      { label = "重新对齐", variant = "filled", onTap = function()
        local list = NC.load(); local _, cur = NC.find(list, id)
        if not cur then return end
        NC.ensure_ws(cur)
        local r = NC.sync_adapter(cur)
        if r == "nocfg" then host.toast("AstrBot 尚未安装, 启动后会自动绑定")
        else host.toast("已重新对齐, 重启 AstrBot 生效") end
      end },
    },
  })
end

-- ===== NapCat 卡片存活探测（只服务 UI 互斥，不改启停语义）=====
-- 判定优先级：端口处于 LISTEN(/proc/net/tcp) > /dev/tcp 可连通 > 进程存在。
-- 三者任一成立即视为"活着"→ 只显示停止；全部不成立才显示播放。
local NC_LIVE = {}          -- id -> true/false，最近一次探测结果
local NC_LIVE_REV = nil     -- state 句柄，set 触发整页重建
local NC_LIVE_T = 0         -- 上次探测时间(ms)，节流用
local NC_LIVE_BUSY = false  -- 防重入

local function nc_live_cmd(list)
  local calls = {}
  for _, ins in ipairs(list) do
    -- 端口以实例自己的 webUiPort 为准；缺失时退回 app 的 napcat 端口配置（默认 6099）
    local port = tonumber(ins.webUiPort) or ports.get("napcat") or 6100
    calls[#calls + 1] = '__nc ' .. port .. ' "' .. tostring(ins.id) .. '"'
  end
  -- 逐级降级：端口 LISTEN → /dev/tcp → 进程名 → pid 文件 → ps
  -- 任何一级成立即判活；全部不成立才判死，避免某一种探测在沙箱里不可用时误判。
  local body =
    '__nc() {\n'
    .. '  p="$1"; id="$2"; H=$(printf "%04X" "$p" 2>/dev/null)\n'
    .. '  if [ -n "$H" ] && grep -q ":$H 00000000:0000 0A" /proc/net/tcp 2>/dev/null; then echo "$id 1"; return; fi\n'
    .. '  if [ -n "$H" ] && grep -q ":$H 00000000000000000000000000000000:0000 0A" /proc/net/tcp6 2>/dev/null; then echo "$id 1"; return; fi\n'
    .. '  if (exec 3<>/dev/tcp/127.0.0.1/$p) 2>/dev/null; then echo "$id 1"; return; fi\n'
    .. '  if pgrep -f "napcat_instances/${id}_napcat" >/dev/null 2>&1; then echo "$id 1"; return; fi\n'
    .. '  pf="/root/napcat_instances/${id}_napcat/qq.pid"; pid=$(cat "$pf" 2>/dev/null)\n'
    .. '  if [ -n "$pid" ] && [ -d "/proc/$pid" ]; then echo "$id 1"; return; fi\n'
    .. '  if ps -ef 2>/dev/null | grep -q "napcat_instances/${id}_napcat"; then echo "$id 1"; return; fi\n'
    .. '  echo "$id 0"\n'
    .. '}\n'
  return body .. table.concat(calls, "; ")
end

local function nc_probe_live(force)
  if NC_LIVE_BUSY then return end
  local now = host.now_ms()
  if not force and (now - NC_LIVE_T) < 1500 then return end
  local list = NC.load()
  if #list == 0 then return end
  NC_LIVE_BUSY = true; NC_LIVE_T = now
  host.exec(nc_live_cmd(list), function(res)
    NC_LIVE_BUSY = false
    local out = (res and res.output) or ""
    local changed = false
    for id, v in out:gmatch("(%S+)%s+([01])") do
      local b = (v == "1")
      if NC_LIVE[id] ~= b then NC_LIVE[id] = b; changed = true end
    end
    if changed and NC_LIVE_REV then NC_LIVE_REV.set(NC_LIVE_REV.get() + 1) end
  end)
end

local function napcat_tile(ins)
  local running = ins.running
  -- 真实存活：探测结果优先；结果还没回来时先沿用 host 的记账值
  local live = NC_LIVE[ins.id]
  if live == nil then live = running end
  -- v2.3.0：真实 QQ 号（ins.qq → onebot11_<uin>.json → webui.json autoLoginAccount）
  local uin = NC.hydrate_qq(ins)
  local logged = uin ~= ""
  local webuiToken = NC.read_webui_token(ins)

  -- 播放 / 停止 严格二选一：同一时刻只构造其中一个控件
  local action
  if live then
    action = iconbutton("stop", function()
      NC.stop(ins.id)
      NC_LIVE[ins.id] = false                       -- 先切回播放，避免连点
      if NC_LIVE_REV then NC_LIVE_REV.set(NC_LIVE_REV.get() + 1) end
      host.delay(1800, function() nc_probe_live(true) end)   -- 再用真实状态校正
    end, { tooltip = "停止", color = "error" })
  else
    action = iconbutton("play_arrow", function()
      NC.start(ins.id)
      NC_LIVE[ins.id] = nil                         -- 交给探测决定，不写死
      if NC_LIVE_REV then NC_LIVE_REV.set(NC_LIVE_REV.get() + 1) end
      host.delay(2500, function() nc_probe_live(true) end)
    end, { tooltip = "启动", color = "primary" })
  end

  return tile(ins.name, {
    -- 左侧图标改成纯状态灯（不再用 play_circle 冒充播放按钮）
    icon = live and "check_circle" or "error_outline",
    iconColor = live and "green" or "grey",
    subtitle = "QQ " .. (logged and uin or "未登录，启动后扫码") .. "\nWebUI " .. tostring(ins.webUiPort),
    trailing = row({
      iconbutton("language", function() host.webview_open(NC.webui_url(ins), ins.name) end, { tooltip = "打开 WebUI" }),
      action,
      menu("more_vert", {
        { label = "编辑", onTap = function()
          host.input({ title = "编辑账号名", default = ins.name }, function(name)
            if name and name ~= "" then NC.edit(ins.id, name, ins.webUiPort) end
          end)
        end },
        { label = "绑定 BOT", onTap = function() bind_bot_dialog(ins) end },
        { label = "复制 token", enabled = webuiToken ~= "", onTap = function()
          local token = NC.read_webui_token(ins)
          if token == "" then host.toast("尚未读取到 WebUI token"); return end
          host.clipboard.copy(token); host.toast("已复制 token")
        end },
        { label = "复制完整链接", onTap = function()
          host.clipboard.copy(NC.webui_url(ins)); host.toast("已复制链接")
        end },
        { label = "退出登录", onTap = function()
          host.confirm("确定退出该账号登录?", function(y) if y then NC.logout(ins.id) end end)
        end },
        { label = "删除", onTap = function()
          host.confirm("确定删除该账号?", function(y) if y then NC.delete(ins.id) end end)
        end },
      }),
    }, { main = "end" }),
  })
end

-- ============================================================
-- 主页 UI · v2.3.0 单卡化
--   v2.2.x 的 astrbot_card（quick_start_card）与 napcat_card 已整体删除：
--   状态灯 / WebUI 入口 / 启停 / 清理 / 账号管理全部收进下面这一张 stack_card。
-- ============================================================

-- 账号与端口（原 napcat_card 的内容，收进 stack_card 的折叠区）
local function accounts_expansion(ctx, st)
  -- 订阅探测结果：变化时整页重建（state 按 key 保留，重建不丢）
  NC_LIVE_REV = state("napcat.live.rev", 0)
  NC_LIVE_REV.get()
  nc_probe_live(false)          -- 渲染顺带探测，1.5s 节流

  local dash = ports.get("dashboard")
  local kids = {
    row({
      expanded(text("NapCat 账号", { size = 12, color = "grey" })),
      iconbutton("add", function() add_napcat() end, { tooltip = "添加账号" }),
    }, { cross = "center" }),
    tile("AstrBot 服务", {
      icon = "smart_toy",
      subtitle = (st.astrbot_live and "运行中" or "已停止") .. " · 127.0.0.1:" .. dash,
      trailing = button(st.astrbot_live and "停止" or "启动", function()
        if st.astrbot_live then
          -- 可能是 boot_services.sh 拉起的，不在 ctx.running 里，补一刀 pkill
          host.stop("astrbot")
          host.exec('pkill -f "AstrBot.*main.py" 2>/dev/null || true')
          host.toast("已停止 AstrBot")
          host.delay(1200, function() live_probe(true) end)
        else
          astrbot_toggle(false)
        end
      end, { variant = "tonal" }),
    }),
    tile("AstrBot 监听端口", {
      icon = "settings_ethernet",
      subtitle = "127.0.0.1:" .. dash .. " · 改完重启 AstrBot 生效",
      trailing = iconbutton("edit_outlined", function()
        host.input({ title = "AstrBot 监听端口", default = tostring(dash), hint = "6185" }, function(v)
          if v and v ~= "" and tonumber(v) then
            ports.set("dashboard", tonumber(v))
            host.toast("端口已保存，重启 AstrBot 后生效")
          end
        end)
      end),
    }),
  }

  local list = NC.load()
  if #list == 0 then
    kids[#kids + 1] = padding(text("暂无账号，点右上角 + 添加", { size = 12, color = "grey" }), 8)
  else
    for _, ins in ipairs(list) do
      ins.running = ctx.running and ctx.running["napcat:" .. ins.id] or false
      kids[#kids + 1] = napcat_tile(ins)
    end
  end
  return expansion("账号与端口（" .. #list .. "）", kids, { icon = "pets" })
end

-- 状态灯
local function lamp(on, label, off_color)
  return row({
    icon("circle", { size = 10, color = on and "green" or (off_color or "red") }),
    spacer(6),
    expanded(text(label, { size = 12, color = "grey", maxLines = 1, ellipsis = true })),
  }, { cross = "center" })
end

-- v2.3.0 新增：两个 WebUI 快捷入口
local function open_astrbot_webui()
  host.webview_open("http://127.0.0.1:" .. ports.get("dashboard") .. "/", "AstrBot")
end

local function open_napcat_webui()
  local list = NC.load()
  if #list == 0 then
    host.toast("还没有 NapCat 账号，展开「账号与端口」先添加")
    return
  end
  if #list == 1 then
    host.webview_open(NC.webui_url(list[1]), list[1].name or "NapCat")
    return
  end
  -- 多实例：让用户选一个（token 各自不同，不能混用）
  local items = {}
  for _, ins in ipairs(list) do
    local uin = NC.hydrate_qq(ins)
    items[#items + 1] = {
      label = (ins.name or ins.id) .. (uin ~= "" and (" · QQ " .. uin) or ""),
      icon = "pets",
      onTap = function() host.webview_open(NC.webui_url(ins), ins.name or "NapCat") end,
    }
  end
  host.sheet({ title = "打开哪个 NapCat WebUI？", items = items })
end

local function clean_space()
  if host.exists("/root/boot_services.sh") then
    -- 走 boot_services.sh clean —— 幂等拉起守护，首轮立刻清一次
    host.spawn("/bin/sh /root/boot_services.sh clean", "清理", "clean")
    host.toast("已启动清理守护并立即清理一轮，结果见终端")
  elseif host.exists("/root/clean_daemon.sh") then
    host.spawn("/bin/sh /root/clean_daemon.sh --apply --yes", "清理", "clean")
    host.toast("正在清理日志、缓存与超期下载包，结果见终端")
  else
    host.toast("未找到 clean_daemon.sh")
  end
end

-- 主页唯一的一张卡：五个状态灯 + 两个 WebUI 入口 + 启停/清理 + 看护 + 账号折叠区
local function stack_card(ctx)
  -- 两个 state 句柄：端口实况 / QQ 号变化都触发整页重建（key 保留，重建不丢）
  LIVE_REV = state("stack.live.rev", 0); LIVE_REV.get()
  QQ_REV = state("stack.qq.rev", 0); QQ_REV.get()
  live_probe(false)          -- 4s 节流：11434(Ollama) + dashboard(AstrBot)
  qq_refresh(false)          -- 8s 节流：日志兜底捞真实 UIN
  local st = stack_state(ctx)

  local nc_label = "NapCat " .. st.napcat_up .. "/" .. st.napcat_total
  local qq_label = (st.qq > 0) and ("QQ " .. table.concat(st.qq_list, "/")) or "QQ 未登录"
  local link_ok = st.astrbot_live and st.napcat_up > 0

  local oll_label, oll_off
  if st.ollama then oll_label = "Ollama 已就绪"; oll_off = "red"
  elseif not st.ollama_ready then oll_label = "Ollama 未安装"; oll_off = "grey"
  else oll_label = "Ollama 已停止"; oll_off = "red" end

  return card("全栈状态 · " .. APP_VERSION, {
    -- 第一排：三个服务灯（v2.3.0 新增 Ollama）
    row({
      expanded(lamp(st.astrbot_live, st.astrbot_live and "AstrBot 运行中" or "AstrBot 已停止")),
      expanded(lamp(st.napcat_up > 0, nc_label)),
      expanded(lamp(st.ollama, oll_label, oll_off)),
    }, { gap = 6 }),
    spacer(8),
    row({
      expanded(lamp(st.qq > 0, qq_label)),
      expanded(lamp(link_ok, link_ok and "链路就绪" or "链路未就绪")),
    }, { gap = 6 }),
    spacer(12),
    -- v2.3.0：WebUI 双入口，不用再去账号菜单里翻
    row({
      expanded(button("AstrBot WebUI", open_astrbot_webui, { icon = "language", variant = "tonal" })),
      expanded(button("NapCat WebUI", open_napcat_webui, { icon = "pets", variant = "tonal" })),
    }, { gap = 12 }),
    spacer(8),
    row({
      expanded(button("一键启动全栈", function() boot_all(ctx) end, { icon = "rocket_launch" })),
      expanded(button("全部停止", function() stop_all(ctx) end,
        { icon = "stop_circle", variant = "outlined", danger = true })),
    }, { gap = 12 }),
    spacer(8),
    row({
      expanded(button("清理空间", clean_space, { icon = "cleaning_services", variant = "tonal" })),
      expanded(button(st.ollama and "停止 Ollama" or "启动 Ollama", function()
        ollama_toggle(st.ollama)          -- v3.1.0：启动会带上 OLLAMA_MODEL 并预热
        host.delay(2500, function() live_probe(true) end)
      end, { icon = "memory", variant = "text" })),
    }, { gap = 12 }),
    spacer(4),
    -- v3.1.0：向量模型改为可点击文字按钮（原来写死在下面的巡检说明里）
    row({
      expanded(button("模型: " .. st.ollama_model .. "（点击修改）", edit_ollama_model,
        { icon = "edit_outlined", variant = "text" })),
    }),
    spacer(4),
    toggle({
      title = "自动看护",
      value = watch_enabled(),
      onChanged = function(v) watch_set(v) end,
    }),
    padding(text(watch_enabled()
      and ("每 " .. math.floor(WATCH.ms / 1000) .. " 秒巡检：Ollama(:" .. st.ollama_port
        .. ") · AstrBot · NapCat 掉线自动拉起，退后台也生效")
      or "已关闭：掉线不会自动恢复", { size = 11, color = "grey" }), 8),
    accounts_expansion(ctx, st),
  })
end

local function do_backup(cb)
  local ub = host.ubuntu_path()
  if not host.exists(ub .. "/root/AstrBot/data") then
    host.toast("AstrBot 数据目录不存在"); if cb then cb(false) end; return
  end
  local dir = host.backup_dir()
  host.mkdirs(dir)
  local name = "AstrBotBubble-backup-" .. os.date("%Y%m%d-%H%M%S") .. ".tar.gz"
  local path = dir .. "/" .. name
  host.run(host.bin_path() .. "/busybox",
    { "tar", "-czf", path, "-C", ub .. "/root/AstrBot", "data" },
    function(res)
      if res.code == 0 then
        host.toast("备份成功: " .. name); if cb then cb(true) end
      else
        host.toast("备份失败: " .. (res.stderr or "")); if cb then cb(false) end
      end
    end)
end

local function do_restore()
  local dir = host.backup_dir()
  local files = {}
  for _, e in ipairs(host.list_dir(dir)) do
    if (not e.isDir) and e.name:match("^AstrBotBubble%-backup%-") and e.name:match("%.tar%.gz$") then
      files[#files + 1] = e
    end
  end
  if #files == 0 then host.toast("未找到备份文件"); return end
  host.dialog({
    title = "选择备份还原",
    build = function()
      local kids = {}
      for _, f in ipairs(files) do
        kids[#kids + 1] = tile(f.name, {
          icon = "restore",
          onTap = function()
            host.confirm("还原将覆盖当前数据，确定?", function(y)
              if y then
                local ub = host.ubuntu_path()
                host.run(host.bin_path() .. "/busybox",
                  { "tar", "-xzf", f.path, "-C", ub .. "/root/AstrBot" },
                  function(res)
                    host.close_dialog()
                    if res.code == 0 then
                      host.toast("还原成功，应用即将退出"); host.exit_app()
                    else
                      host.toast("还原失败: " .. (res.stderr or ""))
                    end
                  end)
              end
            end)
          end,
        })
      end
      return column(kids, { cross = "stretch" })
    end,
  })
end

local function manage_section()
  return expansion("AstrBot 管理", {
    tile("覆盖安装插件依赖", {
      icon = "build_outlined", subtitle = "重新安装 AstrBot 并覆盖插件依赖",
      trailing = button("执行", function() step_astrbot(false, true) end, { variant = "tonal" }),
    }),
    tile("备份 AstrBot 数据", {
      icon = "backup_outlined", subtitle = "打包 data 到下载目录",
      trailing = button("备份", function() do_backup() end, { variant = "tonal" }),
    }),
    tile("还原 AstrBot 数据", {
      icon = "restore", subtitle = "从备份文件恢复 data",
      trailing = button("还原", do_restore, { variant = "tonal" }),
    }),
    tile("清除 AstrBot 数据", {
      icon = "delete_outline", subtitle = "删除 data 数据目录 (不可恢复)",
      trailing = button("清除", function()
        host.confirm("确定要清除 AstrBot 数据吗?", function(yes)
          if yes then host.delete_dir(host.ubuntu_path() .. "/root/AstrBot/data"); host.exit_app() end
        end)
      end, { danger = true }),
    }),
    tile("重置 Python 环境", {
      icon = "refresh", subtitle = "删除 .venv 并重建依赖",
      trailing = button("重置", function()
        host.confirm("确定要重置 Python 环境吗?", function(yes)
          if yes then host.delete_dir(host.ubuntu_path() .. "/root/AstrBot/.venv"); host.exit_app() end
        end)
      end, { danger = true }),
    }),
  }, { icon = "settings_outlined" })
end

app.page("home", function(ctx)
  return {
    stack_card(ctx),   -- v3.1.0：主页唯一主卡（状态灯 + WebUI + 启停 + 清理 + 模型配置 + 账号折叠区）
    env_card(),
    manage_section(),
  }
end)

-- 【本文件新增】启动时若开关是开的，就把后台看护挂上
-- （host.interval 会在 sandbox reload 时自动清理，不会泄漏）
if watch_enabled() then stack_watch_start() end

-- 主页顶栏的两个 Agent 入口按钮已移至受保护的 agent/main.lua,
-- 与本文件解耦: 即使这里被改坏, agent 启动入口依然稳定存在。
